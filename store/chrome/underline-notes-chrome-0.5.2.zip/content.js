/*!
Underline Notes / 划线笔记
Copyright 2026 rockbotcc

https://github.com/rockbotcc/underline-notes

Licensed under the Apache License, Version 2.0.
See LICENSE for the full license text.

Third-party components retain their respective copyrights and licenses.
*/
"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/@mozilla/readability/Readability.js
  var require_Readability = __commonJS({
    "node_modules/@mozilla/readability/Readability.js"(exports, module) {
      function Readability2(doc, options) {
        if (options && options.documentElement) {
          doc = options;
          options = arguments[2];
        } else if (!doc || !doc.documentElement) {
          throw new Error(
            "First argument to Readability constructor should be a document object."
          );
        }
        options = options || {};
        this._doc = doc;
        this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
        this._articleTitle = null;
        this._articleByline = null;
        this._articleDir = null;
        this._articleSiteName = null;
        this._attempts = [];
        this._metadata = {};
        this._debug = !!options.debug;
        this._maxElemsToParse = options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
        this._nbTopCandidates = options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
        this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
        this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(
          options.classesToPreserve || []
        );
        this._keepClasses = !!options.keepClasses;
        this._serializer = options.serializer || function(el) {
          return el.innerHTML;
        };
        this._disableJSONLD = !!options.disableJSONLD;
        this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
        this._linkDensityModifier = options.linkDensityModifier || 0;
        this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
        if (this._debug) {
          let logNode = function(node) {
            if (node.nodeType == node.TEXT_NODE) {
              return `${node.nodeName} ("${node.textContent}")`;
            }
            let attrPairs = Array.from(node.attributes || [], function(attr) {
              return `${attr.name}="${attr.value}"`;
            }).join(" ");
            return `<${node.localName} ${attrPairs}>`;
          };
          this.log = function() {
            if (typeof console !== "undefined") {
              let args = Array.from(arguments, (arg) => {
                if (arg && arg.nodeType == this.ELEMENT_NODE) {
                  return logNode(arg);
                }
                return arg;
              });
              args.unshift("Reader: (Readability)");
              console.log(...args);
            } else if (typeof dump !== "undefined") {
              var msg = Array.prototype.map.call(arguments, function(x) {
                return x && x.nodeName ? logNode(x) : x;
              }).join(" ");
              dump("Reader: (Readability) " + msg + "\n");
            }
          };
        } else {
          this.log = function() {
          };
        }
      }
      Readability2.prototype = {
        FLAG_STRIP_UNLIKELYS: 1,
        FLAG_WEIGHT_CLASSES: 2,
        FLAG_CLEAN_CONDITIONALLY: 4,
        // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        // Max number of nodes supported by this parser. Default: 0 (no limit)
        DEFAULT_MAX_ELEMS_TO_PARSE: 0,
        // The number of top candidates to consider when analysing how
        // tight the competition is among candidates.
        DEFAULT_N_TOP_CANDIDATES: 5,
        // Element tags to score by default.
        DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
        // The default number of chars an article must have in order to return a result
        DEFAULT_CHAR_THRESHOLD: 500,
        // All of the regular expressions in use within readability.
        // Defined up here so we don't instantiate them repeatedly in loops.
        REGEXPS: {
          // NOTE: These two regular expressions are duplicated in
          // Readability-readerable.js. Please keep both copies in sync.
          unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
          okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
          positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
          negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|footer|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|widget/i,
          extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
          byline: /byline|author|dateline|writtenby|p-author/i,
          replaceFonts: /<(\/?)font[^>]*>/gi,
          normalize: /\s{2,}/g,
          videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
          shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
          nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
          prevLink: /(prev|earl|old|new|<|«)/i,
          tokenize: /\W+/g,
          whitespace: /^\s*$/,
          hasContent: /\S$/,
          hashUrl: /^#.+/,
          srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
          b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
          // Commas as used in Latin, Sindhi, Chinese and various other scripts.
          // see: https://en.wikipedia.org/wiki/Comma#Comma_variants
          commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
          // See: https://schema.org/Article
          jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/,
          // used to see if a node's content matches words commonly used for ad blocks or loading indicators
          adWords: /^(ad(vertising|vertisement)?|pub(licité)?|werb(ung)?|广告|Реклама|Anuncio)$/iu,
          loadingWords: /^((loading|正在加载|Загрузка|chargement|cargando)(…|\.\.\.)?)$/iu
        },
        UNLIKELY_ROLES: [
          "menu",
          "menubar",
          "complementary",
          "navigation",
          "alert",
          "alertdialog",
          "dialog"
        ],
        DIV_TO_P_ELEMS: /* @__PURE__ */ new Set([
          "BLOCKQUOTE",
          "DL",
          "DIV",
          "IMG",
          "OL",
          "P",
          "PRE",
          "TABLE",
          "UL"
        ]),
        ALTER_TO_DIV_EXCEPTIONS: ["DIV", "ARTICLE", "SECTION", "P", "OL", "UL"],
        PRESENTATIONAL_ATTRIBUTES: [
          "align",
          "background",
          "bgcolor",
          "border",
          "cellpadding",
          "cellspacing",
          "frame",
          "hspace",
          "rules",
          "style",
          "valign",
          "vspace"
        ],
        DEPRECATED_SIZE_ATTRIBUTE_ELEMS: ["TABLE", "TH", "TD", "HR", "PRE"],
        // The commented out elements qualify as phrasing content but tend to be
        // removed by readability when put into paragraphs, so we ignore them here.
        PHRASING_ELEMS: [
          // "CANVAS", "IFRAME", "SVG", "VIDEO",
          "ABBR",
          "AUDIO",
          "B",
          "BDO",
          "BR",
          "BUTTON",
          "CITE",
          "CODE",
          "DATA",
          "DATALIST",
          "DFN",
          "EM",
          "EMBED",
          "I",
          "IMG",
          "INPUT",
          "KBD",
          "LABEL",
          "MARK",
          "MATH",
          "METER",
          "NOSCRIPT",
          "OBJECT",
          "OUTPUT",
          "PROGRESS",
          "Q",
          "RUBY",
          "SAMP",
          "SCRIPT",
          "SELECT",
          "SMALL",
          "SPAN",
          "STRONG",
          "SUB",
          "SUP",
          "TEXTAREA",
          "TIME",
          "VAR",
          "WBR"
        ],
        // These are the classes that readability sets itself.
        CLASSES_TO_PRESERVE: ["page"],
        // These are the list of HTML entities that need to be escaped.
        HTML_ESCAPE_MAP: {
          lt: "<",
          gt: ">",
          amp: "&",
          quot: '"',
          apos: "'"
        },
        /**
         * Run any post-process modifications to article content as necessary.
         *
         * @param Element
         * @return void
         **/
        _postProcessContent(articleContent) {
          this._fixRelativeUris(articleContent);
          this._simplifyNestedElements(articleContent);
          if (!this._keepClasses) {
            this._cleanClasses(articleContent);
          }
        },
        /**
         * Iterates over a NodeList, calls `filterFn` for each node and removes node
         * if function returned `true`.
         *
         * If function is not passed, removes all the nodes in node list.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param Function filterFn the function to use as a filter
         * @return void
         */
        _removeNodes(nodeList, filterFn) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _removeNodes");
          }
          for (var i = nodeList.length - 1; i >= 0; i--) {
            var node = nodeList[i];
            var parentNode = node.parentNode;
            if (parentNode) {
              if (!filterFn || filterFn.call(this, node, i, nodeList)) {
                parentNode.removeChild(node);
              }
            }
          }
        },
        /**
         * Iterates over a NodeList, and calls _setNodeTag for each node.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param String newTagName the new tag name to use
         * @return void
         */
        _replaceNodeTags(nodeList, newTagName) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _replaceNodeTags");
          }
          for (const node of nodeList) {
            this._setNodeTag(node, newTagName);
          }
        },
        /**
         * Iterate over a NodeList, which doesn't natively fully implement the Array
         * interface.
         *
         * For convenience, the current object context is applied to the provided
         * iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return void
         */
        _forEachNode(nodeList, fn) {
          Array.prototype.forEach.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, and return the first node that passes
         * the supplied test function
         *
         * For convenience, the current object context is applied to the provided
         * test function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The test function.
         * @return void
         */
        _findNode(nodeList, fn) {
          return Array.prototype.find.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if any of the provided iterate
         * function calls returns true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _someNode(nodeList, fn) {
          return Array.prototype.some.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if all of the provided iterate
         * function calls return true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _everyNode(nodeList, fn) {
          return Array.prototype.every.call(nodeList, fn, this);
        },
        _getAllNodesWithTag(node, tagNames) {
          if (node.querySelectorAll) {
            return node.querySelectorAll(tagNames.join(","));
          }
          return [].concat.apply(
            [],
            tagNames.map(function(tag) {
              var collection = node.getElementsByTagName(tag);
              return Array.isArray(collection) ? collection : Array.from(collection);
            })
          );
        },
        /**
         * Removes the class="" attribute from every element in the given
         * subtree, except those that match CLASSES_TO_PRESERVE and
         * the classesToPreserve array from the options object.
         *
         * @param Element
         * @return void
         */
        _cleanClasses(node) {
          var classesToPreserve = this._classesToPreserve;
          var className = (node.getAttribute("class") || "").split(/\s+/).filter((cls) => classesToPreserve.includes(cls)).join(" ");
          if (className) {
            node.setAttribute("class", className);
          } else {
            node.removeAttribute("class");
          }
          for (node = node.firstElementChild; node; node = node.nextElementSibling) {
            this._cleanClasses(node);
          }
        },
        /**
         * Tests whether a string is a URL or not.
         *
         * @param {string} str The string to test
         * @return {boolean} true if str is a URL, false if not
         */
        _isUrl(str) {
          try {
            new URL(str);
            return true;
          } catch {
            return false;
          }
        },
        /**
         * Converts each <a> and <img> uri in the given element to an absolute URI,
         * ignoring #ref URIs.
         *
         * @param Element
         * @return void
         */
        _fixRelativeUris(articleContent) {
          var baseURI = this._doc.baseURI;
          var documentURI = this._doc.documentURI;
          function toAbsoluteURI(uri) {
            if (baseURI == documentURI && uri.charAt(0) == "#") {
              return uri;
            }
            try {
              return new URL(uri, baseURI).href;
            } catch (ex) {
            }
            return uri;
          }
          var links = this._getAllNodesWithTag(articleContent, ["a"]);
          this._forEachNode(links, function(link) {
            var href = link.getAttribute("href");
            if (href) {
              if (href.indexOf("javascript:") === 0) {
                if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
                  var text = this._doc.createTextNode(link.textContent);
                  link.parentNode.replaceChild(text, link);
                } else {
                  var container = this._doc.createElement("span");
                  while (link.firstChild) {
                    container.appendChild(link.firstChild);
                  }
                  link.parentNode.replaceChild(container, link);
                }
              } else {
                link.setAttribute("href", toAbsoluteURI(href));
              }
            }
          });
          var medias = this._getAllNodesWithTag(articleContent, [
            "img",
            "picture",
            "figure",
            "video",
            "audio",
            "source"
          ]);
          this._forEachNode(medias, function(media) {
            var src = media.getAttribute("src");
            var poster = media.getAttribute("poster");
            var srcset = media.getAttribute("srcset");
            if (src) {
              media.setAttribute("src", toAbsoluteURI(src));
            }
            if (poster) {
              media.setAttribute("poster", toAbsoluteURI(poster));
            }
            if (srcset) {
              var newSrcset = srcset.replace(
                this.REGEXPS.srcsetUrl,
                function(_, p1, p2, p3) {
                  return toAbsoluteURI(p1) + (p2 || "") + p3;
                }
              );
              media.setAttribute("srcset", newSrcset);
            }
          });
        },
        _simplifyNestedElements(articleContent) {
          var node = articleContent;
          while (node) {
            if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
              if (this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              } else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
                var child = node.children[0];
                for (var i = 0; i < node.attributes.length; i++) {
                  child.setAttributeNode(node.attributes[i].cloneNode());
                }
                node.parentNode.replaceChild(child, node);
                node = child;
                continue;
              }
            }
            node = this._getNextNode(node);
          }
        },
        /**
         * Get the article title as an H1.
         *
         * @return string
         **/
        _getArticleTitle() {
          var doc = this._doc;
          var curTitle = "";
          var origTitle = "";
          try {
            curTitle = origTitle = doc.title.trim();
            if (typeof curTitle !== "string") {
              curTitle = origTitle = this._getInnerText(
                doc.getElementsByTagName("title")[0]
              );
            }
          } catch (e) {
          }
          var titleHadHierarchicalSeparators = false;
          function wordCount(str) {
            return str.split(/\s+/).length;
          }
          if (/ [\|\-\\\/>»] /.test(curTitle)) {
            titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
            let allSeparators = Array.from(origTitle.matchAll(/ [\|\-\\\/>»] /gi));
            curTitle = origTitle.substring(0, allSeparators.pop().index);
            if (wordCount(curTitle) < 3) {
              curTitle = origTitle.replace(/^[^\|\-\\\/>»]*[\|\-\\\/>»]/gi, "");
            }
          } else if (curTitle.includes(": ")) {
            var headings = this._getAllNodesWithTag(doc, ["h1", "h2"]);
            var trimmedTitle = curTitle.trim();
            var match = this._someNode(headings, function(heading) {
              return heading.textContent.trim() === trimmedTitle;
            });
            if (!match) {
              curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
              if (wordCount(curTitle) < 3) {
                curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
              } else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) {
                curTitle = origTitle;
              }
            }
          } else if (curTitle.length > 150 || curTitle.length < 15) {
            var hOnes = doc.getElementsByTagName("h1");
            if (hOnes.length === 1) {
              curTitle = this._getInnerText(hOnes[0]);
            }
          }
          curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
          var curTitleWordCount = wordCount(curTitle);
          if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) {
            curTitle = origTitle;
          }
          return curTitle;
        },
        /**
         * Prepare the HTML document for readability to scrape it.
         * This includes things like stripping javascript, CSS, and handling terrible markup.
         *
         * @return void
         **/
        _prepDocument() {
          var doc = this._doc;
          this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
          if (doc.body) {
            this._replaceBrs(doc.body);
          }
          this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
        },
        /**
         * Finds the next node, starting from the given node, and ignoring
         * whitespace in between. If the given node is an element, the same node is
         * returned.
         */
        _nextNode(node) {
          var next2 = node;
          while (next2 && next2.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next2.textContent)) {
            next2 = next2.nextSibling;
          }
          return next2;
        },
        /**
         * Replaces 2 or more successive <br> elements with a single <p>.
         * Whitespace between <br> elements are ignored. For example:
         *   <div>foo<br>bar<br> <br><br>abc</div>
         * will become:
         *   <div>foo<br>bar<p>abc</p></div>
         */
        _replaceBrs(elem) {
          this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
            var next2 = br.nextSibling;
            var replaced = false;
            while ((next2 = this._nextNode(next2)) && next2.tagName == "BR") {
              replaced = true;
              var brSibling = next2.nextSibling;
              next2.remove();
              next2 = brSibling;
            }
            if (replaced) {
              var p = this._doc.createElement("p");
              br.parentNode.replaceChild(p, br);
              next2 = p.nextSibling;
              while (next2) {
                if (next2.tagName == "BR") {
                  var nextElem = this._nextNode(next2.nextSibling);
                  if (nextElem && nextElem.tagName == "BR") {
                    break;
                  }
                }
                if (!this._isPhrasingContent(next2)) {
                  break;
                }
                var sibling = next2.nextSibling;
                p.appendChild(next2);
                next2 = sibling;
              }
              while (p.lastChild && this._isWhitespace(p.lastChild)) {
                p.lastChild.remove();
              }
              if (p.parentNode.tagName === "P") {
                this._setNodeTag(p.parentNode, "DIV");
              }
            }
          });
        },
        _setNodeTag(node, tag) {
          this.log("_setNodeTag", node, tag);
          if (this._docJSDOMParser) {
            node.localName = tag.toLowerCase();
            node.tagName = tag.toUpperCase();
            return node;
          }
          var replacement = node.ownerDocument.createElement(tag);
          while (node.firstChild) {
            replacement.appendChild(node.firstChild);
          }
          node.parentNode.replaceChild(replacement, node);
          if (node.readability) {
            replacement.readability = node.readability;
          }
          for (var i = 0; i < node.attributes.length; i++) {
            replacement.setAttributeNode(node.attributes[i].cloneNode());
          }
          return replacement;
        },
        /**
         * Prepare the article node for display. Clean out any inline styles,
         * iframes, forms, strip extraneous <p> tags, etc.
         *
         * @param Element
         * @return void
         **/
        _prepArticle(articleContent) {
          this._cleanStyles(articleContent);
          this._markDataTables(articleContent);
          this._fixLazyImages(articleContent);
          this._cleanConditionally(articleContent, "form");
          this._cleanConditionally(articleContent, "fieldset");
          this._clean(articleContent, "object");
          this._clean(articleContent, "embed");
          this._clean(articleContent, "footer");
          this._clean(articleContent, "link");
          this._clean(articleContent, "aside");
          var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
          this._forEachNode(articleContent.children, function(topCandidate) {
            this._cleanMatchedNodes(topCandidate, function(node, matchString) {
              return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
            });
          });
          this._clean(articleContent, "iframe");
          this._clean(articleContent, "input");
          this._clean(articleContent, "textarea");
          this._clean(articleContent, "select");
          this._clean(articleContent, "button");
          this._cleanHeaders(articleContent);
          this._cleanConditionally(articleContent, "table");
          this._cleanConditionally(articleContent, "ul");
          this._cleanConditionally(articleContent, "div");
          this._replaceNodeTags(
            this._getAllNodesWithTag(articleContent, ["h1"]),
            "h2"
          );
          this._removeNodes(
            this._getAllNodesWithTag(articleContent, ["p"]),
            function(paragraph) {
              var contentElementCount = this._getAllNodesWithTag(paragraph, [
                "img",
                "embed",
                "object",
                "iframe"
              ]).length;
              return contentElementCount === 0 && !this._getInnerText(paragraph, false);
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["br"]),
            function(br) {
              var next2 = this._nextNode(br.nextSibling);
              if (next2 && next2.tagName == "P") {
                br.remove();
              }
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["table"]),
            function(table) {
              var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
              if (this._hasSingleTagInsideElement(tbody, "TR")) {
                var row = tbody.firstElementChild;
                if (this._hasSingleTagInsideElement(row, "TD")) {
                  var cell = row.firstElementChild;
                  cell = this._setNodeTag(
                    cell,
                    this._everyNode(cell.childNodes, this._isPhrasingContent) ? "P" : "DIV"
                  );
                  table.parentNode.replaceChild(cell, table);
                }
              }
            }
          );
        },
        /**
         * Initialize a node with the readability object. Also checks the
         * className/id for special names to add to its score.
         *
         * @param Element
         * @return void
         **/
        _initializeNode(node) {
          node.readability = { contentScore: 0 };
          switch (node.tagName) {
            case "DIV":
              node.readability.contentScore += 5;
              break;
            case "PRE":
            case "TD":
            case "BLOCKQUOTE":
              node.readability.contentScore += 3;
              break;
            case "ADDRESS":
            case "OL":
            case "UL":
            case "DL":
            case "DD":
            case "DT":
            case "LI":
            case "FORM":
              node.readability.contentScore -= 3;
              break;
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "TH":
              node.readability.contentScore -= 5;
              break;
          }
          node.readability.contentScore += this._getClassWeight(node);
        },
        _removeAndGetNext(node) {
          var nextNode = this._getNextNode(node, true);
          node.remove();
          return nextNode;
        },
        /**
         * Traverse the DOM from node to node, starting at the node passed in.
         * Pass true for the second parameter to indicate this node itself
         * (and its kids) are going away, and we want the next node over.
         *
         * Calling this in a loop will traverse the DOM depth-first.
         *
         * @param {Element} node
         * @param {boolean} ignoreSelfAndKids
         * @return {Element}
         */
        _getNextNode(node, ignoreSelfAndKids) {
          if (!ignoreSelfAndKids && node.firstElementChild) {
            return node.firstElementChild;
          }
          if (node.nextElementSibling) {
            return node.nextElementSibling;
          }
          do {
            node = node.parentNode;
          } while (node && !node.nextElementSibling);
          return node && node.nextElementSibling;
        },
        // compares second text to first one
        // 1 = same text, 0 = completely different text
        // works the way that it splits both texts into words and then finds words that are unique in second text
        // the result is given by the lower length of unique parts
        _textSimilarity(textA, textB) {
          var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          if (!tokensA.length || !tokensB.length) {
            return 0;
          }
          var uniqTokensB = tokensB.filter((token) => !tokensA.includes(token));
          var distanceB = uniqTokensB.join(" ").length / tokensB.join(" ").length;
          return 1 - distanceB;
        },
        /**
         * Checks whether an element node contains a valid byline
         *
         * @param node {Element}
         * @param matchString {string}
         * @return boolean
         */
        _isValidByline(node, matchString) {
          var rel = node.getAttribute("rel");
          var itemprop = node.getAttribute("itemprop");
          var bylineLength = node.textContent.trim().length;
          return (rel === "author" || itemprop && itemprop.includes("author") || this.REGEXPS.byline.test(matchString)) && !!bylineLength && bylineLength < 100;
        },
        _getNodeAncestors(node, maxDepth) {
          maxDepth = maxDepth || 0;
          var i = 0, ancestors = [];
          while (node.parentNode) {
            ancestors.push(node.parentNode);
            if (maxDepth && ++i === maxDepth) {
              break;
            }
            node = node.parentNode;
          }
          return ancestors;
        },
        /***
         * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
         *         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
         *
         * @param page a document to run upon. Needs to be a full document, complete with body.
         * @return Element
         **/
        /* eslint-disable-next-line complexity */
        _grabArticle(page2) {
          this.log("**** grabArticle ****");
          var doc = this._doc;
          var isPaging = page2 !== null;
          page2 = page2 ? page2 : this._doc.body;
          if (!page2) {
            this.log("No body found in document. Abort.");
            return null;
          }
          var pageCacheHtml = page2.innerHTML;
          while (true) {
            this.log("Starting grabArticle loop");
            var stripUnlikelyCandidates = this._flagIsActive(
              this.FLAG_STRIP_UNLIKELYS
            );
            var elementsToScore = [];
            var node = this._doc.documentElement;
            let shouldRemoveTitleHeader = true;
            while (node) {
              if (node.tagName === "HTML") {
                this._articleLang = node.getAttribute("lang");
              }
              var matchString = node.className + " " + node.id;
              if (!this._isProbablyVisible(node)) {
                this.log("Removing hidden node - " + matchString);
                node = this._removeAndGetNext(node);
                continue;
              }
              if (node.getAttribute("aria-modal") == "true" && node.getAttribute("role") == "dialog") {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (!this._articleByline && !this._metadata.byline && this._isValidByline(node, matchString)) {
                var endOfSearchMarkerNode = this._getNextNode(node, true);
                var next2 = this._getNextNode(node);
                var itemPropNameNode = null;
                while (next2 && next2 != endOfSearchMarkerNode) {
                  var itemprop = next2.getAttribute("itemprop");
                  if (itemprop && itemprop.includes("name")) {
                    itemPropNameNode = next2;
                    break;
                  } else {
                    next2 = this._getNextNode(next2);
                  }
                }
                this._articleByline = (itemPropNameNode ?? node).textContent.trim();
                node = this._removeAndGetNext(node);
                continue;
              }
              if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
                this.log(
                  "Removing header: ",
                  node.textContent.trim(),
                  this._articleTitle.trim()
                );
                shouldRemoveTitleHeader = false;
                node = this._removeAndGetNext(node);
                continue;
              }
              if (stripUnlikelyCandidates) {
                if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
                  this.log("Removing unlikely candidate - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
                if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
                  this.log(
                    "Removing content with role " + node.getAttribute("role") + " - " + matchString
                  );
                  node = this._removeAndGetNext(node);
                  continue;
                }
              }
              if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this.DEFAULT_TAGS_TO_SCORE.includes(node.tagName)) {
                elementsToScore.push(node);
              }
              if (node.tagName === "DIV") {
                var p = null;
                var childNode = node.firstChild;
                while (childNode) {
                  var nextSibling = childNode.nextSibling;
                  if (this._isPhrasingContent(childNode)) {
                    if (p !== null) {
                      p.appendChild(childNode);
                    } else if (!this._isWhitespace(childNode)) {
                      p = doc.createElement("p");
                      node.replaceChild(p, childNode);
                      p.appendChild(childNode);
                    }
                  } else if (p !== null) {
                    while (p.lastChild && this._isWhitespace(p.lastChild)) {
                      p.lastChild.remove();
                    }
                    p = null;
                  }
                  childNode = nextSibling;
                }
                if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < 0.25) {
                  var newNode = node.children[0];
                  node.parentNode.replaceChild(newNode, node);
                  node = newNode;
                  elementsToScore.push(node);
                } else if (!this._hasChildBlockElement(node)) {
                  node = this._setNodeTag(node, "P");
                  elementsToScore.push(node);
                }
              }
              node = this._getNextNode(node);
            }
            var candidates = [];
            this._forEachNode(elementsToScore, function(elementToScore) {
              if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined") {
                return;
              }
              var innerText = this._getInnerText(elementToScore);
              if (innerText.length < 25) {
                return;
              }
              var ancestors2 = this._getNodeAncestors(elementToScore, 5);
              if (ancestors2.length === 0) {
                return;
              }
              var contentScore = 0;
              contentScore += 1;
              contentScore += innerText.split(this.REGEXPS.commas).length;
              contentScore += Math.min(Math.floor(innerText.length / 100), 3);
              this._forEachNode(ancestors2, function(ancestor, level) {
                if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined") {
                  return;
                }
                if (typeof ancestor.readability === "undefined") {
                  this._initializeNode(ancestor);
                  candidates.push(ancestor);
                }
                if (level === 0) {
                  var scoreDivider = 1;
                } else if (level === 1) {
                  scoreDivider = 2;
                } else {
                  scoreDivider = level * 3;
                }
                ancestor.readability.contentScore += contentScore / scoreDivider;
              });
            });
            var topCandidates = [];
            for (var c = 0, cl = candidates.length; c < cl; c += 1) {
              var candidate = candidates[c];
              var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
              candidate.readability.contentScore = candidateScore;
              this.log("Candidate:", candidate, "with score " + candidateScore);
              for (var t = 0; t < this._nbTopCandidates; t++) {
                var aTopCandidate = topCandidates[t];
                if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
                  topCandidates.splice(t, 0, candidate);
                  if (topCandidates.length > this._nbTopCandidates) {
                    topCandidates.pop();
                  }
                  break;
                }
              }
            }
            var topCandidate = topCandidates[0] || null;
            var neededToCreateTopCandidate = false;
            var parentOfTopCandidate;
            if (topCandidate === null || topCandidate.tagName === "BODY") {
              topCandidate = doc.createElement("DIV");
              neededToCreateTopCandidate = true;
              while (page2.firstChild) {
                this.log("Moving child out:", page2.firstChild);
                topCandidate.appendChild(page2.firstChild);
              }
              page2.appendChild(topCandidate);
              this._initializeNode(topCandidate);
            } else if (topCandidate) {
              var alternativeCandidateAncestors = [];
              for (var i = 1; i < topCandidates.length; i++) {
                if (topCandidates[i].readability.contentScore / topCandidate.readability.contentScore >= 0.75) {
                  alternativeCandidateAncestors.push(
                    this._getNodeAncestors(topCandidates[i])
                  );
                }
              }
              var MINIMUM_TOPCANDIDATES = 3;
              if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
                parentOfTopCandidate = topCandidate.parentNode;
                while (parentOfTopCandidate.tagName !== "BODY") {
                  var listsContainingThisAncestor = 0;
                  for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) {
                    listsContainingThisAncestor += Number(
                      alternativeCandidateAncestors[ancestorIndex].includes(
                        parentOfTopCandidate
                      )
                    );
                  }
                  if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
                    topCandidate = parentOfTopCandidate;
                    break;
                  }
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                }
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
              parentOfTopCandidate = topCandidate.parentNode;
              var lastScore = topCandidate.readability.contentScore;
              var scoreThreshold = lastScore / 3;
              while (parentOfTopCandidate.tagName !== "BODY") {
                if (!parentOfTopCandidate.readability) {
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                  continue;
                }
                var parentScore = parentOfTopCandidate.readability.contentScore;
                if (parentScore < scoreThreshold) {
                  break;
                }
                if (parentScore > lastScore) {
                  topCandidate = parentOfTopCandidate;
                  break;
                }
                lastScore = parentOfTopCandidate.readability.contentScore;
                parentOfTopCandidate = parentOfTopCandidate.parentNode;
              }
              parentOfTopCandidate = topCandidate.parentNode;
              while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
                topCandidate = parentOfTopCandidate;
                parentOfTopCandidate = topCandidate.parentNode;
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
            }
            var articleContent = doc.createElement("DIV");
            if (isPaging) {
              articleContent.id = "readability-content";
            }
            var siblingScoreThreshold = Math.max(
              10,
              topCandidate.readability.contentScore * 0.2
            );
            parentOfTopCandidate = topCandidate.parentNode;
            var siblings = parentOfTopCandidate.children;
            for (var s = 0, sl = siblings.length; s < sl; s++) {
              var sibling = siblings[s];
              var append = false;
              this.log(
                "Looking at sibling node:",
                sibling,
                sibling.readability ? "with score " + sibling.readability.contentScore : ""
              );
              this.log(
                "Sibling has score",
                sibling.readability ? sibling.readability.contentScore : "Unknown"
              );
              if (sibling === topCandidate) {
                append = true;
              } else {
                var contentBonus = 0;
                if (sibling.className === topCandidate.className && topCandidate.className !== "") {
                  contentBonus += topCandidate.readability.contentScore * 0.2;
                }
                if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) {
                  append = true;
                } else if (sibling.nodeName === "P") {
                  var linkDensity = this._getLinkDensity(sibling);
                  var nodeContent = this._getInnerText(sibling);
                  var nodeLength = nodeContent.length;
                  if (nodeLength > 80 && linkDensity < 0.25) {
                    append = true;
                  } else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) {
                    append = true;
                  }
                }
              }
              if (append) {
                this.log("Appending node:", sibling);
                if (!this.ALTER_TO_DIV_EXCEPTIONS.includes(sibling.nodeName)) {
                  this.log("Altering sibling:", sibling, "to div.");
                  sibling = this._setNodeTag(sibling, "DIV");
                }
                articleContent.appendChild(sibling);
                siblings = parentOfTopCandidate.children;
                s -= 1;
                sl -= 1;
              }
            }
            if (this._debug) {
              this.log("Article content pre-prep: " + articleContent.innerHTML);
            }
            this._prepArticle(articleContent);
            if (this._debug) {
              this.log("Article content post-prep: " + articleContent.innerHTML);
            }
            if (neededToCreateTopCandidate) {
              topCandidate.id = "readability-page-1";
              topCandidate.className = "page";
            } else {
              var div = doc.createElement("DIV");
              div.id = "readability-page-1";
              div.className = "page";
              while (articleContent.firstChild) {
                div.appendChild(articleContent.firstChild);
              }
              articleContent.appendChild(div);
            }
            if (this._debug) {
              this.log("Article content after paging: " + articleContent.innerHTML);
            }
            var parseSuccessful = true;
            var textLength = this._getInnerText(articleContent, true).length;
            if (textLength < this._charThreshold) {
              parseSuccessful = false;
              page2.innerHTML = pageCacheHtml;
              this._attempts.push({
                articleContent,
                textLength
              });
              if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) {
                this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
              } else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
                this._removeFlag(this.FLAG_WEIGHT_CLASSES);
              } else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
                this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
              } else {
                this._attempts.sort(function(a, b) {
                  return b.textLength - a.textLength;
                });
                if (!this._attempts[0].textLength) {
                  return null;
                }
                articleContent = this._attempts[0].articleContent;
                parseSuccessful = true;
              }
            }
            if (parseSuccessful) {
              var ancestors = [parentOfTopCandidate, topCandidate].concat(
                this._getNodeAncestors(parentOfTopCandidate)
              );
              this._someNode(ancestors, function(ancestor) {
                if (!ancestor.tagName) {
                  return false;
                }
                var articleDir = ancestor.getAttribute("dir");
                if (articleDir) {
                  this._articleDir = articleDir;
                  return true;
                }
                return false;
              });
              return articleContent;
            }
          }
        },
        /**
         * Converts some of the common HTML entities in string to their corresponding characters.
         *
         * @param str {string} - a string to unescape.
         * @return string without HTML entity.
         */
        _unescapeHtmlEntities(str) {
          if (!str) {
            return str;
          }
          var htmlEscapeMap = this.HTML_ESCAPE_MAP;
          return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_, tag) {
            return htmlEscapeMap[tag];
          }).replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, function(_, hex, numStr) {
            var num = parseInt(hex || numStr, hex ? 16 : 10);
            if (num == 0 || num > 1114111 || num >= 55296 && num <= 57343) {
              num = 65533;
            }
            return String.fromCodePoint(num);
          });
        },
        /**
         * Try to extract metadata from JSON-LD object.
         * For now, only Schema.org objects of type Article or its subtypes are supported.
         * @return Object with any metadata that could be extracted (possibly none)
         */
        _getJSONLD(doc) {
          var scripts = this._getAllNodesWithTag(doc, ["script"]);
          var metadata;
          this._forEachNode(scripts, function(jsonLdElement) {
            if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") {
              try {
                var content = jsonLdElement.textContent.replace(
                  /^\s*<!\[CDATA\[|\]\]>\s*$/g,
                  ""
                );
                var parsed = JSON.parse(content);
                if (Array.isArray(parsed)) {
                  parsed = parsed.find((it) => {
                    return it["@type"] && it["@type"].match(this.REGEXPS.jsonLdArticleTypes);
                  });
                  if (!parsed) {
                    return;
                  }
                }
                var schemaDotOrgRegex = /^https?\:\/\/schema\.org\/?$/;
                var matches = typeof parsed["@context"] === "string" && parsed["@context"].match(schemaDotOrgRegex) || typeof parsed["@context"] === "object" && typeof parsed["@context"]["@vocab"] == "string" && parsed["@context"]["@vocab"].match(schemaDotOrgRegex);
                if (!matches) {
                  return;
                }
                if (!parsed["@type"] && Array.isArray(parsed["@graph"])) {
                  parsed = parsed["@graph"].find((it) => {
                    return (it["@type"] || "").match(this.REGEXPS.jsonLdArticleTypes);
                  });
                }
                if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) {
                  return;
                }
                metadata = {};
                if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
                  var title = this._getArticleTitle();
                  var nameMatches = this._textSimilarity(parsed.name, title) > 0.75;
                  var headlineMatches = this._textSimilarity(parsed.headline, title) > 0.75;
                  if (headlineMatches && !nameMatches) {
                    metadata.title = parsed.headline;
                  } else {
                    metadata.title = parsed.name;
                  }
                } else if (typeof parsed.name === "string") {
                  metadata.title = parsed.name.trim();
                } else if (typeof parsed.headline === "string") {
                  metadata.title = parsed.headline.trim();
                }
                if (parsed.author) {
                  if (typeof parsed.author.name === "string") {
                    metadata.byline = parsed.author.name.trim();
                  } else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") {
                    metadata.byline = parsed.author.filter(function(author) {
                      return author && typeof author.name === "string";
                    }).map(function(author) {
                      return author.name.trim();
                    }).join(", ");
                  }
                }
                if (typeof parsed.description === "string") {
                  metadata.excerpt = parsed.description.trim();
                }
                if (parsed.publisher && typeof parsed.publisher.name === "string") {
                  metadata.siteName = parsed.publisher.name.trim();
                }
                if (typeof parsed.datePublished === "string") {
                  metadata.datePublished = parsed.datePublished.trim();
                }
              } catch (err) {
                this.log(err.message);
              }
            }
          });
          return metadata ? metadata : {};
        },
        /**
         * Attempts to get excerpt and byline metadata for the article.
         *
         * @param {Object} jsonld — object containing any metadata that
         * could be extracted from JSON-LD object.
         *
         * @return Object with optional "excerpt" and "byline" properties
         */
        _getArticleMetadata(jsonld) {
          var metadata = {};
          var values = {};
          var metaElements = this._doc.getElementsByTagName("meta");
          var propertyPattern = /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;
          var namePattern = /^\s*(?:(dc|dcterm|og|twitter|parsely|weibo:(article|webpage))\s*[-\.:]\s*)?(author|creator|pub-date|description|title|site_name)\s*$/i;
          this._forEachNode(metaElements, function(element2) {
            var elementName = element2.getAttribute("name");
            var elementProperty = element2.getAttribute("property");
            var content = element2.getAttribute("content");
            if (!content) {
              return;
            }
            var matches = null;
            var name = null;
            if (elementProperty) {
              matches = elementProperty.match(propertyPattern);
              if (matches) {
                name = matches[0].toLowerCase().replace(/\s/g, "");
                values[name] = content.trim();
              }
            }
            if (!matches && elementName && namePattern.test(elementName)) {
              name = elementName;
              if (content) {
                name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
                values[name] = content.trim();
              }
            }
          });
          metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values.title || values["twitter:title"] || values["parsely-title"];
          if (!metadata.title) {
            metadata.title = this._getArticleTitle();
          }
          const articleAuthor = typeof values["article:author"] === "string" && !this._isUrl(values["article:author"]) ? values["article:author"] : void 0;
          metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values.author || values["parsely-author"] || articleAuthor;
          metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values.description || values["twitter:description"];
          metadata.siteName = jsonld.siteName || values["og:site_name"];
          metadata.publishedTime = jsonld.datePublished || values["article:published_time"] || values["parsely-pub-date"] || null;
          metadata.title = this._unescapeHtmlEntities(metadata.title);
          metadata.byline = this._unescapeHtmlEntities(metadata.byline);
          metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
          metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
          metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);
          return metadata;
        },
        /**
         * Check if node is image, or if node contains exactly only one image
         * whether as a direct child or as its descendants.
         *
         * @param Element
         **/
        _isSingleImage(node) {
          while (node) {
            if (node.tagName === "IMG") {
              return true;
            }
            if (node.children.length !== 1 || node.textContent.trim() !== "") {
              return false;
            }
            node = node.children[0];
          }
          return false;
        },
        /**
         * Find all <noscript> that are located after <img> nodes, and which contain only one
         * <img> element. Replace the first image with the image from inside the <noscript> tag,
         * and remove the <noscript> tag. This improves the quality of the images we use on
         * some sites (e.g. Medium).
         *
         * @param Element
         **/
        _unwrapNoscriptImages(doc) {
          var imgs = Array.from(doc.getElementsByTagName("img"));
          this._forEachNode(imgs, function(img) {
            for (var i = 0; i < img.attributes.length; i++) {
              var attr = img.attributes[i];
              switch (attr.name) {
                case "src":
                case "srcset":
                case "data-src":
                case "data-srcset":
                  return;
              }
              if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                return;
              }
            }
            img.remove();
          });
          var noscripts = Array.from(doc.getElementsByTagName("noscript"));
          this._forEachNode(noscripts, function(noscript) {
            if (!this._isSingleImage(noscript)) {
              return;
            }
            var tmp = doc.createElement("div");
            tmp.innerHTML = noscript.innerHTML;
            var prevElement = noscript.previousElementSibling;
            if (prevElement && this._isSingleImage(prevElement)) {
              var prevImg = prevElement;
              if (prevImg.tagName !== "IMG") {
                prevImg = prevElement.getElementsByTagName("img")[0];
              }
              var newImg = tmp.getElementsByTagName("img")[0];
              for (var i = 0; i < prevImg.attributes.length; i++) {
                var attr = prevImg.attributes[i];
                if (attr.value === "") {
                  continue;
                }
                if (attr.name === "src" || attr.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                  if (newImg.getAttribute(attr.name) === attr.value) {
                    continue;
                  }
                  var attrName = attr.name;
                  if (newImg.hasAttribute(attrName)) {
                    attrName = "data-old-" + attrName;
                  }
                  newImg.setAttribute(attrName, attr.value);
                }
              }
              noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
            }
          });
        },
        /**
         * Removes script tags from the document.
         *
         * @param Element
         **/
        _removeScripts(doc) {
          this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
        },
        /**
         * Check if this node has only whitespace and a single element with given tag
         * Returns false if the DIV node contains non-empty text nodes
         * or if it contains no element with given tag or more than 1 element.
         *
         * @param Element
         * @param string tag of child element
         **/
        _hasSingleTagInsideElement(element2, tag) {
          if (element2.children.length != 1 || element2.children[0].tagName !== tag) {
            return false;
          }
          return !this._someNode(element2.childNodes, function(node) {
            return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
          });
        },
        _isElementWithoutContent(node) {
          return node.nodeType === this.ELEMENT_NODE && !node.textContent.trim().length && (!node.children.length || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
        },
        /**
         * Determine whether element has any children block level elements.
         *
         * @param Element
         */
        _hasChildBlockElement(element2) {
          return this._someNode(element2.childNodes, function(node) {
            return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
          });
        },
        /***
         * Determine if a node qualifies as phrasing content.
         * https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
         **/
        _isPhrasingContent(node) {
          return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.includes(node.tagName) || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
        },
        _isWhitespace(node) {
          return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
        },
        /**
         * Get the inner text of a node - cross browser compatibly.
         * This also strips out any excess whitespace to be found.
         *
         * @param Element
         * @param Boolean normalizeSpaces (default: true)
         * @return string
         **/
        _getInnerText(e, normalizeSpaces) {
          normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
          var textContent = e.textContent.trim();
          if (normalizeSpaces) {
            return textContent.replace(this.REGEXPS.normalize, " ");
          }
          return textContent;
        },
        /**
         * Get the number of times a string s appears in the node e.
         *
         * @param Element
         * @param string - what to split on. Default is ","
         * @return number (integer)
         **/
        _getCharCount(e, s) {
          s = s || ",";
          return this._getInnerText(e).split(s).length - 1;
        },
        /**
         * Remove the style attribute on every e and under.
         * TODO: Test if getElementsByTagName(*) is faster.
         *
         * @param Element
         * @return void
         **/
        _cleanStyles(e) {
          if (!e || e.tagName.toLowerCase() === "svg") {
            return;
          }
          for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) {
            e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
          }
          if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.includes(e.tagName)) {
            e.removeAttribute("width");
            e.removeAttribute("height");
          }
          var cur = e.firstElementChild;
          while (cur !== null) {
            this._cleanStyles(cur);
            cur = cur.nextElementSibling;
          }
        },
        /**
         * Get the density of links as a percentage of the content
         * This is the amount of text that is inside a link divided by the total text in the node.
         *
         * @param Element
         * @return number (float)
         **/
        _getLinkDensity(element2) {
          var textLength = this._getInnerText(element2).length;
          if (textLength === 0) {
            return 0;
          }
          var linkLength = 0;
          this._forEachNode(element2.getElementsByTagName("a"), function(linkNode) {
            var href = linkNode.getAttribute("href");
            var coefficient = href && this.REGEXPS.hashUrl.test(href) ? 0.3 : 1;
            linkLength += this._getInnerText(linkNode).length * coefficient;
          });
          return linkLength / textLength;
        },
        /**
         * Get an elements class/id weight. Uses regular expressions to tell if this
         * element looks good or bad.
         *
         * @param Element
         * @return number (Integer)
         **/
        _getClassWeight(e) {
          if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
            return 0;
          }
          var weight = 0;
          if (typeof e.className === "string" && e.className !== "") {
            if (this.REGEXPS.negative.test(e.className)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.className)) {
              weight += 25;
            }
          }
          if (typeof e.id === "string" && e.id !== "") {
            if (this.REGEXPS.negative.test(e.id)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.id)) {
              weight += 25;
            }
          }
          return weight;
        },
        /**
         * Clean a node of all elements of type "tag".
         * (Unless it's a youtube/vimeo video. People love movies.)
         *
         * @param Element
         * @param string tag to clean
         * @return void
         **/
        _clean(e, tag) {
          var isEmbed = ["object", "embed", "iframe"].includes(tag);
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(element2) {
            if (isEmbed) {
              for (var i = 0; i < element2.attributes.length; i++) {
                if (this._allowedVideoRegex.test(element2.attributes[i].value)) {
                  return false;
                }
              }
              if (element2.tagName === "object" && this._allowedVideoRegex.test(element2.innerHTML)) {
                return false;
              }
            }
            return true;
          });
        },
        /**
         * Check if a given node has one of its ancestor tag name matching the
         * provided one.
         * @param  HTMLElement node
         * @param  String      tagName
         * @param  Number      maxDepth
         * @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
         * @return Boolean
         */
        _hasAncestorTag(node, tagName, maxDepth, filterFn) {
          maxDepth = maxDepth || 3;
          tagName = tagName.toUpperCase();
          var depth = 0;
          while (node.parentNode) {
            if (maxDepth > 0 && depth > maxDepth) {
              return false;
            }
            if (node.parentNode.tagName === tagName && (!filterFn || filterFn(node.parentNode))) {
              return true;
            }
            node = node.parentNode;
            depth++;
          }
          return false;
        },
        /**
         * Return an object indicating how many rows and columns this table has.
         */
        _getRowAndColumnCount(table) {
          var rows = 0;
          var columns = 0;
          var trs = table.getElementsByTagName("tr");
          for (var i = 0; i < trs.length; i++) {
            var rowspan = trs[i].getAttribute("rowspan") || 0;
            if (rowspan) {
              rowspan = parseInt(rowspan, 10);
            }
            rows += rowspan || 1;
            var columnsInThisRow = 0;
            var cells = trs[i].getElementsByTagName("td");
            for (var j = 0; j < cells.length; j++) {
              var colspan = cells[j].getAttribute("colspan") || 0;
              if (colspan) {
                colspan = parseInt(colspan, 10);
              }
              columnsInThisRow += colspan || 1;
            }
            columns = Math.max(columns, columnsInThisRow);
          }
          return { rows, columns };
        },
        /**
         * Look for 'data' (as opposed to 'layout') tables, for which we use
         * similar checks as
         * https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
         */
        _markDataTables(root2) {
          var tables = root2.getElementsByTagName("table");
          for (var i = 0; i < tables.length; i++) {
            var table = tables[i];
            var role = table.getAttribute("role");
            if (role == "presentation") {
              table._readabilityDataTable = false;
              continue;
            }
            var datatable = table.getAttribute("datatable");
            if (datatable == "0") {
              table._readabilityDataTable = false;
              continue;
            }
            var summary = table.getAttribute("summary");
            if (summary) {
              table._readabilityDataTable = true;
              continue;
            }
            var caption = table.getElementsByTagName("caption")[0];
            if (caption && caption.childNodes.length) {
              table._readabilityDataTable = true;
              continue;
            }
            var dataTableDescendants = ["col", "colgroup", "tfoot", "thead", "th"];
            var descendantExists = function(tag) {
              return !!table.getElementsByTagName(tag)[0];
            };
            if (dataTableDescendants.some(descendantExists)) {
              this.log("Data table because found data-y descendant");
              table._readabilityDataTable = true;
              continue;
            }
            if (table.getElementsByTagName("table")[0]) {
              table._readabilityDataTable = false;
              continue;
            }
            var sizeInfo = this._getRowAndColumnCount(table);
            if (sizeInfo.columns == 1 || sizeInfo.rows == 1) {
              table._readabilityDataTable = false;
              continue;
            }
            if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
              table._readabilityDataTable = true;
              continue;
            }
            table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
          }
        },
        /* convert images and figures that have properties like data-src into images that can be loaded without JS */
        _fixLazyImages(root2) {
          this._forEachNode(
            this._getAllNodesWithTag(root2, ["img", "picture", "figure"]),
            function(elem) {
              if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
                var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
                if (parts[1] === "image/svg+xml") {
                  return;
                }
                var srcCouldBeRemoved = false;
                for (var i = 0; i < elem.attributes.length; i++) {
                  var attr = elem.attributes[i];
                  if (attr.name === "src") {
                    continue;
                  }
                  if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                    srcCouldBeRemoved = true;
                    break;
                  }
                }
                if (srcCouldBeRemoved) {
                  var b64starts = parts[0].length;
                  var b64length = elem.src.length - b64starts;
                  if (b64length < 133) {
                    elem.removeAttribute("src");
                  }
                }
              }
              if ((elem.src || elem.srcset && elem.srcset != "null") && !elem.className.toLowerCase().includes("lazy")) {
                return;
              }
              for (var j = 0; j < elem.attributes.length; j++) {
                attr = elem.attributes[j];
                if (attr.name === "src" || attr.name === "srcset" || attr.name === "alt") {
                  continue;
                }
                var copyTo = null;
                if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) {
                  copyTo = "srcset";
                } else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) {
                  copyTo = "src";
                }
                if (copyTo) {
                  if (elem.tagName === "IMG" || elem.tagName === "PICTURE") {
                    elem.setAttribute(copyTo, attr.value);
                  } else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
                    var img = this._doc.createElement("img");
                    img.setAttribute(copyTo, attr.value);
                    elem.appendChild(img);
                  }
                }
              }
            }
          );
        },
        _getTextDensity(e, tags) {
          var textLength = this._getInnerText(e, true).length;
          if (textLength === 0) {
            return 0;
          }
          var childrenLength = 0;
          var children = this._getAllNodesWithTag(e, tags);
          this._forEachNode(
            children,
            (child) => childrenLength += this._getInnerText(child, true).length
          );
          return childrenLength / textLength;
        },
        /**
         * Clean an element of all tags of type "tag" if they look fishy.
         * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
         *
         * @return void
         **/
        _cleanConditionally(e, tag) {
          if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
            return;
          }
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(node) {
            var isDataTable = function(t) {
              return t._readabilityDataTable;
            };
            var isList = tag === "ul" || tag === "ol";
            if (!isList) {
              var listLength = 0;
              var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
              this._forEachNode(
                listNodes,
                (list) => listLength += this._getInnerText(list).length
              );
              isList = listLength / this._getInnerText(node).length > 0.9;
            }
            if (tag === "table" && isDataTable(node)) {
              return false;
            }
            if (this._hasAncestorTag(node, "table", -1, isDataTable)) {
              return false;
            }
            if (this._hasAncestorTag(node, "code")) {
              return false;
            }
            if ([...node.getElementsByTagName("table")].some(
              (tbl) => tbl._readabilityDataTable
            )) {
              return false;
            }
            var weight = this._getClassWeight(node);
            this.log("Cleaning Conditionally", node);
            var contentScore = 0;
            if (weight + contentScore < 0) {
              return true;
            }
            if (this._getCharCount(node, ",") < 10) {
              var p = node.getElementsByTagName("p").length;
              var img = node.getElementsByTagName("img").length;
              var li = node.getElementsByTagName("li").length - 100;
              var input = node.getElementsByTagName("input").length;
              var headingDensity = this._getTextDensity(node, [
                "h1",
                "h2",
                "h3",
                "h4",
                "h5",
                "h6"
              ]);
              var embedCount = 0;
              var embeds = this._getAllNodesWithTag(node, [
                "object",
                "embed",
                "iframe"
              ]);
              for (var i = 0; i < embeds.length; i++) {
                for (var j = 0; j < embeds[i].attributes.length; j++) {
                  if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) {
                    return false;
                  }
                }
                if (embeds[i].tagName === "object" && this._allowedVideoRegex.test(embeds[i].innerHTML)) {
                  return false;
                }
                embedCount++;
              }
              var innerText = this._getInnerText(node);
              if (this.REGEXPS.adWords.test(innerText) || this.REGEXPS.loadingWords.test(innerText)) {
                return true;
              }
              var contentLength = innerText.length;
              var linkDensity = this._getLinkDensity(node);
              var textishTags = ["SPAN", "LI", "TD"].concat(
                Array.from(this.DIV_TO_P_ELEMS)
              );
              var textDensity = this._getTextDensity(node, textishTags);
              var isFigureChild = this._hasAncestorTag(node, "figure");
              const shouldRemoveNode = () => {
                const errs = [];
                if (!isFigureChild && img > 1 && p / img < 0.5) {
                  errs.push(`Bad p to img ratio (img=${img}, p=${p})`);
                }
                if (!isList && li > p) {
                  errs.push(`Too many li's outside of a list. (li=${li} > p=${p})`);
                }
                if (input > Math.floor(p / 3)) {
                  errs.push(`Too many inputs per p. (input=${input}, p=${p})`);
                }
                if (!isList && !isFigureChild && headingDensity < 0.9 && contentLength < 25 && (img === 0 || img > 2) && linkDensity > 0) {
                  errs.push(
                    `Suspiciously short. (headingDensity=${headingDensity}, img=${img}, linkDensity=${linkDensity})`
                  );
                }
                if (!isList && weight < 25 && linkDensity > 0.2 + this._linkDensityModifier) {
                  errs.push(
                    `Low weight and a little linky. (linkDensity=${linkDensity})`
                  );
                }
                if (weight >= 25 && linkDensity > 0.5 + this._linkDensityModifier) {
                  errs.push(
                    `High weight and mostly links. (linkDensity=${linkDensity})`
                  );
                }
                if (embedCount === 1 && contentLength < 75 || embedCount > 1) {
                  errs.push(
                    `Suspicious embed. (embedCount=${embedCount}, contentLength=${contentLength})`
                  );
                }
                if (img === 0 && textDensity === 0) {
                  errs.push(
                    `No useful content. (img=${img}, textDensity=${textDensity})`
                  );
                }
                if (errs.length) {
                  this.log("Checks failed", errs);
                  return true;
                }
                return false;
              };
              var haveToRemove = shouldRemoveNode();
              if (isList && haveToRemove) {
                for (var x = 0; x < node.children.length; x++) {
                  let child = node.children[x];
                  if (child.children.length > 1) {
                    return haveToRemove;
                  }
                }
                let li_count = node.getElementsByTagName("li").length;
                if (img == li_count) {
                  return false;
                }
              }
              return haveToRemove;
            }
            return false;
          });
        },
        /**
         * Clean out elements that match the specified conditions
         *
         * @param Element
         * @param Function determines whether a node should be removed
         * @return void
         **/
        _cleanMatchedNodes(e, filter) {
          var endOfSearchMarkerNode = this._getNextNode(e, true);
          var next2 = this._getNextNode(e);
          while (next2 && next2 != endOfSearchMarkerNode) {
            if (filter.call(this, next2, next2.className + " " + next2.id)) {
              next2 = this._removeAndGetNext(next2);
            } else {
              next2 = this._getNextNode(next2);
            }
          }
        },
        /**
         * Clean out spurious headers from an Element.
         *
         * @param Element
         * @return void
         **/
        _cleanHeaders(e) {
          let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
          this._removeNodes(headingNodes, function(node) {
            let shouldRemove = this._getClassWeight(node) < 0;
            if (shouldRemove) {
              this.log("Removing header with low class weight:", node);
            }
            return shouldRemove;
          });
        },
        /**
         * Check if this node is an H1 or H2 element whose content is mostly
         * the same as the article title.
         *
         * @param Element  the node to check.
         * @return boolean indicating whether this is a title-like header.
         */
        _headerDuplicatesTitle(node) {
          if (node.tagName != "H1" && node.tagName != "H2") {
            return false;
          }
          var heading = this._getInnerText(node, false);
          this.log("Evaluating similarity of header:", heading, this._articleTitle);
          return this._textSimilarity(this._articleTitle, heading) > 0.75;
        },
        _flagIsActive(flag) {
          return (this._flags & flag) > 0;
        },
        _removeFlag(flag) {
          this._flags = this._flags & ~flag;
        },
        _isProbablyVisible(node) {
          return (!node.style || node.style.display != "none") && (!node.style || node.style.visibility != "hidden") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
          (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
        },
        /**
         * Runs readability.
         *
         * Workflow:
         *  1. Prep the document by removing script tags, css, etc.
         *  2. Build readability's DOM tree.
         *  3. Grab the article content from the current dom tree.
         *  4. Replace the current DOM tree with the new one.
         *  5. Read peacefully.
         *
         * @return void
         **/
        parse() {
          if (this._maxElemsToParse > 0) {
            var numTags = this._doc.getElementsByTagName("*").length;
            if (numTags > this._maxElemsToParse) {
              throw new Error(
                "Aborting parsing document; " + numTags + " elements found"
              );
            }
          }
          this._unwrapNoscriptImages(this._doc);
          var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
          this._removeScripts(this._doc);
          this._prepDocument();
          var metadata = this._getArticleMetadata(jsonLd);
          this._metadata = metadata;
          this._articleTitle = metadata.title;
          var articleContent = this._grabArticle();
          if (!articleContent) {
            return null;
          }
          this.log("Grabbed: " + articleContent.innerHTML);
          this._postProcessContent(articleContent);
          if (!metadata.excerpt) {
            var paragraphs = articleContent.getElementsByTagName("p");
            if (paragraphs.length) {
              metadata.excerpt = paragraphs[0].textContent.trim();
            }
          }
          var textContent = articleContent.textContent;
          return {
            title: this._articleTitle,
            byline: metadata.byline || this._articleByline,
            dir: this._articleDir,
            lang: this._articleLang,
            content: this._serializer(articleContent),
            textContent,
            length: textContent.length,
            excerpt: metadata.excerpt,
            siteName: metadata.siteName || this._articleSiteName,
            publishedTime: metadata.publishedTime
          };
        }
      };
      if (typeof module === "object") {
        module.exports = Readability2;
      }
    }
  });

  // node_modules/@mozilla/readability/Readability-readerable.js
  var require_Readability_readerable = __commonJS({
    "node_modules/@mozilla/readability/Readability-readerable.js"(exports, module) {
      var REGEXPS = {
        // NOTE: These two regular expressions are duplicated in
        // Readability.js. Please keep both copies in sync.
        unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
        okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
      };
      function isNodeVisible(node) {
        return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
        (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
      }
      function isProbablyReaderable2(doc, options = {}) {
        if (typeof options == "function") {
          options = { visibilityChecker: options };
        }
        var defaultOptions = {
          minScore: 20,
          minContentLength: 140,
          visibilityChecker: isNodeVisible
        };
        options = Object.assign(defaultOptions, options);
        var nodes = doc.querySelectorAll("p, pre, article");
        var brNodes = doc.querySelectorAll("div > br");
        if (brNodes.length) {
          var set = new Set(nodes);
          [].forEach.call(brNodes, function(node) {
            set.add(node.parentNode);
          });
          nodes = Array.from(set);
        }
        var score = 0;
        return [].some.call(nodes, function(node) {
          if (!options.visibilityChecker(node)) {
            return false;
          }
          var matchString = node.className + " " + node.id;
          if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) {
            return false;
          }
          if (node.matches("li p")) {
            return false;
          }
          var textContentLength = node.textContent.trim().length;
          if (textContentLength < options.minContentLength) {
            return false;
          }
          score += Math.sqrt(textContentLength - options.minContentLength);
          if (score > options.minScore) {
            return true;
          }
          return false;
        });
      }
      if (typeof module === "object") {
        module.exports = isProbablyReaderable2;
      }
    }
  });

  // node_modules/@mozilla/readability/index.js
  var require_readability = __commonJS({
    "node_modules/@mozilla/readability/index.js"(exports, module) {
      var Readability2 = require_Readability();
      var isProbablyReaderable2 = require_Readability_readerable();
      module.exports = {
        Readability: Readability2,
        isProbablyReaderable: isProbablyReaderable2
      };
    }
  });

  // browser/src/content.ts
  var import_readability2 = __toESM(require_readability(), 1);

  // browser/src/capture.ts
  var import_readability = __toESM(require_readability(), 1);

  // node_modules/turndown/lib/turndown.browser.es.js
  function extend(destination) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) destination[key] = source[key];
      }
    }
    return destination;
  }
  function repeat(character, count) {
    return Array(count + 1).join(character);
  }
  function trimLeadingNewlines(string) {
    return string.replace(/^\n*/, "");
  }
  function trimTrailingNewlines(string) {
    var indexEnd = string.length;
    while (indexEnd > 0 && string[indexEnd - 1] === "\n") indexEnd--;
    return string.substring(0, indexEnd);
  }
  function trimNewlines(string) {
    return trimTrailingNewlines(trimLeadingNewlines(string));
  }
  var blockElements = ["ADDRESS", "ARTICLE", "ASIDE", "AUDIO", "BLOCKQUOTE", "BODY", "CANVAS", "CENTER", "DD", "DIR", "DIV", "DL", "DT", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "FRAMESET", "H1", "H2", "H3", "H4", "H5", "H6", "HEADER", "HGROUP", "HR", "HTML", "ISINDEX", "LI", "MAIN", "MENU", "NAV", "NOFRAMES", "NOSCRIPT", "OL", "OUTPUT", "P", "PRE", "SECTION", "TABLE", "TBODY", "TD", "TFOOT", "TH", "THEAD", "TR", "UL"];
  function isBlock(node) {
    return is(node, blockElements);
  }
  var voidElements = ["AREA", "BASE", "BR", "COL", "COMMAND", "EMBED", "HR", "IMG", "INPUT", "KEYGEN", "LINK", "META", "PARAM", "SOURCE", "TRACK", "WBR"];
  function isVoid(node) {
    return is(node, voidElements);
  }
  function hasVoid(node) {
    return has(node, voidElements);
  }
  var meaningfulWhenBlankElements = ["A", "TABLE", "THEAD", "TBODY", "TFOOT", "TH", "TD", "IFRAME", "SCRIPT", "AUDIO", "VIDEO"];
  function isMeaningfulWhenBlank(node) {
    return is(node, meaningfulWhenBlankElements);
  }
  function hasMeaningfulWhenBlank(node) {
    return has(node, meaningfulWhenBlankElements);
  }
  function is(node, tagNames) {
    return tagNames.indexOf(node.nodeName) >= 0;
  }
  function has(node, tagNames) {
    return node.getElementsByTagName && tagNames.some(function(tagName) {
      return node.getElementsByTagName(tagName).length;
    });
  }
  var markdownEscapes = [[/\\/g, "\\\\"], [/\*/g, "\\*"], [/^-/g, "\\-"], [/^\+ /g, "\\+ "], [/^(=+)/g, "\\$1"], [/^(#{1,6}) /g, "\\$1 "], [/`/g, "\\`"], [/^~~~/g, "\\~~~"], [/\[/g, "\\["], [/\]/g, "\\]"], [/^>/g, "\\>"], [/_/g, "\\_"], [/^(\d+)\. /g, "$1\\. "]];
  function escapeMarkdown(string) {
    return markdownEscapes.reduce(function(accumulator, escape) {
      return accumulator.replace(escape[0], escape[1]);
    }, string);
  }
  var rules = {};
  rules.paragraph = {
    filter: "p",
    replacement: function(content) {
      return "\n\n" + content + "\n\n";
    }
  };
  rules.lineBreak = {
    filter: "br",
    replacement: function(content, node, options) {
      return options.br + "\n";
    }
  };
  rules.heading = {
    filter: ["h1", "h2", "h3", "h4", "h5", "h6"],
    replacement: function(content, node, options) {
      var hLevel = Number(node.nodeName.charAt(1));
      if (options.headingStyle === "setext" && hLevel < 3) {
        var underline = repeat(hLevel === 1 ? "=" : "-", content.length);
        return "\n\n" + content + "\n" + underline + "\n\n";
      } else {
        return "\n\n" + repeat("#", hLevel) + " " + content + "\n\n";
      }
    }
  };
  rules.blockquote = {
    filter: "blockquote",
    replacement: function(content) {
      content = trimNewlines(content).replace(/^/gm, "> ");
      return "\n\n" + content + "\n\n";
    }
  };
  rules.list = {
    filter: ["ul", "ol"],
    replacement: function(content, node) {
      var parent = node.parentNode;
      if (parent.nodeName === "LI" && parent.lastElementChild === node) {
        return "\n" + content;
      } else {
        return "\n\n" + content + "\n\n";
      }
    }
  };
  rules.listItem = {
    filter: "li",
    replacement: function(content, node, options) {
      var prefix = options.bulletListMarker + "   ";
      var parent = node.parentNode;
      if (parent.nodeName === "OL") {
        var start = parent.getAttribute("start");
        var index = Array.prototype.indexOf.call(parent.children, node);
        prefix = (start ? Number(start) + index : index + 1) + ".  ";
      }
      var isParagraph = /\n$/.test(content);
      content = trimNewlines(content) + (isParagraph ? "\n" : "");
      content = content.replace(/\n/gm, "\n" + " ".repeat(prefix.length));
      return prefix + content + (node.nextSibling ? "\n" : "");
    }
  };
  rules.indentedCodeBlock = {
    filter: function(node, options) {
      return options.codeBlockStyle === "indented" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
    },
    replacement: function(content, node, options) {
      return "\n\n    " + node.firstChild.textContent.replace(/\n/g, "\n    ") + "\n\n";
    }
  };
  rules.fencedCodeBlock = {
    filter: function(node, options) {
      return options.codeBlockStyle === "fenced" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
    },
    replacement: function(content, node, options) {
      var className = node.firstChild.getAttribute("class") || "";
      var language = (className.match(/language-(\S+)/) || [null, ""])[1];
      var code = node.firstChild.textContent;
      var fenceChar = options.fence.charAt(0);
      var fenceSize = 3;
      var fenceInCodeRegex = new RegExp("^" + fenceChar + "{3,}", "gm");
      var match;
      while (match = fenceInCodeRegex.exec(code)) {
        if (match[0].length >= fenceSize) {
          fenceSize = match[0].length + 1;
        }
      }
      var fence = repeat(fenceChar, fenceSize);
      return "\n\n" + fence + language + "\n" + code.replace(/\n$/, "") + "\n" + fence + "\n\n";
    }
  };
  rules.horizontalRule = {
    filter: "hr",
    replacement: function(content, node, options) {
      return "\n\n" + options.hr + "\n\n";
    }
  };
  rules.inlineLink = {
    filter: function(node, options) {
      return options.linkStyle === "inlined" && node.nodeName === "A" && node.getAttribute("href");
    },
    replacement: function(content, node) {
      var href = escapeLinkDestination(node.getAttribute("href"));
      var title = escapeLinkTitle(cleanAttribute(node.getAttribute("title")));
      var titlePart = title ? ' "' + title + '"' : "";
      return "[" + content + "](" + href + titlePart + ")";
    }
  };
  rules.referenceLink = {
    filter: function(node, options) {
      return options.linkStyle === "referenced" && node.nodeName === "A" && node.getAttribute("href");
    },
    replacement: function(content, node, options) {
      var href = escapeLinkDestination(node.getAttribute("href"));
      var title = cleanAttribute(node.getAttribute("title"));
      if (title) title = ' "' + escapeLinkTitle(title) + '"';
      var replacement;
      var reference;
      switch (options.linkReferenceStyle) {
        case "collapsed":
          replacement = "[" + content + "][]";
          reference = "[" + content + "]: " + href + title;
          break;
        case "shortcut":
          replacement = "[" + content + "]";
          reference = "[" + content + "]: " + href + title;
          break;
        default:
          var id = this.references.length + 1;
          replacement = "[" + content + "][" + id + "]";
          reference = "[" + id + "]: " + href + title;
      }
      this.references.push(reference);
      return replacement;
    },
    references: [],
    append: function(options) {
      var references = "";
      if (this.references.length) {
        references = "\n\n" + this.references.join("\n") + "\n\n";
        this.references = [];
      }
      return references;
    }
  };
  rules.emphasis = {
    filter: ["em", "i"],
    replacement: function(content, node, options) {
      if (!content.trim()) return "";
      return options.emDelimiter + content + options.emDelimiter;
    }
  };
  rules.strong = {
    filter: ["strong", "b"],
    replacement: function(content, node, options) {
      if (!content.trim()) return "";
      return options.strongDelimiter + content + options.strongDelimiter;
    }
  };
  rules.code = {
    filter: function(node) {
      var hasSiblings = node.previousSibling || node.nextSibling;
      var isCodeBlock = node.parentNode.nodeName === "PRE" && !hasSiblings;
      return node.nodeName === "CODE" && !isCodeBlock;
    },
    replacement: function(content) {
      if (!content) return "";
      content = content.replace(/\r?\n|\r/g, " ");
      var extraSpace = /^`|^ .*?[^ ].* $|`$/.test(content) ? " " : "";
      var delimiter = "`";
      var matches = content.match(/`+/gm) || [];
      while (matches.indexOf(delimiter) !== -1) delimiter = delimiter + "`";
      return delimiter + extraSpace + content + extraSpace + delimiter;
    }
  };
  rules.image = {
    filter: "img",
    replacement: function(content, node) {
      var alt = escapeMarkdown(cleanAttribute(node.getAttribute("alt")));
      var src = escapeLinkDestination(node.getAttribute("src") || "");
      var title = cleanAttribute(node.getAttribute("title"));
      var titlePart = title ? ' "' + escapeLinkTitle(title) + '"' : "";
      return src ? "![" + alt + "](" + src + titlePart + ")" : "";
    }
  };
  function cleanAttribute(attribute) {
    return attribute ? attribute.replace(/(\n+\s*)+/g, "\n") : "";
  }
  function escapeLinkDestination(destination) {
    var escaped = destination.replace(/([<>()])/g, "\\$1");
    return escaped.indexOf(" ") >= 0 ? "<" + escaped + ">" : escaped;
  }
  function escapeLinkTitle(title) {
    return title.replace(/"/g, '\\"');
  }
  function Rules(options) {
    this.options = options;
    this._keep = [];
    this._remove = [];
    this.blankRule = {
      replacement: options.blankReplacement
    };
    this.keepReplacement = options.keepReplacement;
    this.defaultRule = {
      replacement: options.defaultReplacement
    };
    this.array = [];
    for (var key in options.rules) this.array.push(options.rules[key]);
  }
  Rules.prototype = {
    add: function(key, rule) {
      this.array.unshift(rule);
    },
    keep: function(filter) {
      this._keep.unshift({
        filter,
        replacement: this.keepReplacement
      });
    },
    remove: function(filter) {
      this._remove.unshift({
        filter,
        replacement: function() {
          return "";
        }
      });
    },
    forNode: function(node) {
      if (node.isBlank) return this.blankRule;
      var rule;
      if (rule = findRule(this.array, node, this.options)) return rule;
      if (rule = findRule(this._keep, node, this.options)) return rule;
      if (rule = findRule(this._remove, node, this.options)) return rule;
      return this.defaultRule;
    },
    forEach: function(fn) {
      for (var i = 0; i < this.array.length; i++) fn(this.array[i], i);
    }
  };
  function findRule(rules2, node, options) {
    for (var i = 0; i < rules2.length; i++) {
      var rule = rules2[i];
      if (filterValue(rule, node, options)) return rule;
    }
    return void 0;
  }
  function filterValue(rule, node, options) {
    var filter = rule.filter;
    if (typeof filter === "string") {
      if (filter === node.nodeName.toLowerCase()) return true;
    } else if (Array.isArray(filter)) {
      if (filter.indexOf(node.nodeName.toLowerCase()) > -1) return true;
    } else if (typeof filter === "function") {
      if (filter.call(rule, node, options)) return true;
    } else {
      throw new TypeError("`filter` needs to be a string, array, or function");
    }
  }
  function collapseWhitespace(options) {
    var element2 = options.element;
    var isBlock2 = options.isBlock;
    var isVoid2 = options.isVoid;
    var isPre = options.isPre || function(node2) {
      return node2.nodeName === "PRE";
    };
    if (!element2.firstChild || isPre(element2)) return;
    var prevText = null;
    var keepLeadingWs = false;
    var prev = null;
    var node = next(prev, element2, isPre);
    while (node !== element2) {
      if (node.nodeType === 3 || node.nodeType === 4) {
        var text = node.data.replace(/[ \r\n\t]+/g, " ");
        if ((!prevText || / $/.test(prevText.data)) && !keepLeadingWs && text[0] === " ") {
          text = text.substr(1);
        }
        if (!text) {
          node = remove(node);
          continue;
        }
        node.data = text;
        prevText = node;
      } else if (node.nodeType === 1) {
        if (isBlock2(node) || node.nodeName === "BR") {
          if (prevText) {
            prevText.data = prevText.data.replace(/ $/, "");
          }
          prevText = null;
          keepLeadingWs = false;
        } else if (isVoid2(node) || isPre(node)) {
          prevText = null;
          keepLeadingWs = true;
        } else if (prevText) {
          keepLeadingWs = false;
        }
      } else {
        node = remove(node);
        continue;
      }
      var nextNode = next(prev, node, isPre);
      prev = node;
      node = nextNode;
    }
    if (prevText) {
      prevText.data = prevText.data.replace(/ $/, "");
      if (!prevText.data) {
        remove(prevText);
      }
    }
  }
  function remove(node) {
    var next2 = node.nextSibling || node.parentNode;
    node.parentNode.removeChild(node);
    return next2;
  }
  function next(prev, current, isPre) {
    if (prev && prev.parentNode === current || isPre(current)) {
      return current.nextSibling || current.parentNode;
    }
    return current.firstChild || current.nextSibling || current.parentNode;
  }
  var root = typeof window !== "undefined" ? window : {};
  function canParseHTMLNatively() {
    var Parser = root.DOMParser;
    var canParse = false;
    try {
      if (new Parser().parseFromString("", "text/html")) {
        canParse = true;
      }
    } catch (e) {
    }
    return canParse;
  }
  function createHTMLParser() {
    var Parser = function() {
    };
    {
      if (shouldUseActiveX()) {
        Parser.prototype.parseFromString = function(string) {
          var doc = new window.ActiveXObject("htmlfile");
          doc.designMode = "on";
          doc.open();
          doc.write(string);
          doc.close();
          return doc;
        };
      } else {
        Parser.prototype.parseFromString = function(string) {
          var doc = document.implementation.createHTMLDocument("");
          doc.open();
          doc.write(string);
          doc.close();
          return doc;
        };
      }
    }
    return Parser;
  }
  function shouldUseActiveX() {
    var useActiveX = false;
    try {
      document.implementation.createHTMLDocument("").open();
    } catch (e) {
      if (root.ActiveXObject) useActiveX = true;
    }
    return useActiveX;
  }
  var HTMLParser = canParseHTMLNatively() ? root.DOMParser : createHTMLParser();
  function RootNode(input, options) {
    var root2;
    if (typeof input === "string") {
      var doc = htmlParser().parseFromString(
        // DOM parsers arrange elements in the <head> and <body>.
        // Wrapping in a custom element ensures elements are reliably arranged in
        // a single element.
        '<x-turndown id="turndown-root">' + input + "</x-turndown>",
        "text/html"
      );
      root2 = doc.getElementById("turndown-root");
    } else {
      root2 = input.cloneNode(true);
    }
    collapseWhitespace({
      element: root2,
      isBlock,
      isVoid,
      isPre: options.preformattedCode ? isPreOrCode : null
    });
    return root2;
  }
  var _htmlParser;
  function htmlParser() {
    _htmlParser = _htmlParser || new HTMLParser();
    return _htmlParser;
  }
  function isPreOrCode(node) {
    return node.nodeName === "PRE" || node.nodeName === "CODE";
  }
  function Node2(node, options) {
    node.isBlock = isBlock(node);
    node.isCode = node.nodeName === "CODE" || node.parentNode.isCode;
    node.isBlank = isBlank(node);
    node.flankingWhitespace = flankingWhitespace(node, options);
    return node;
  }
  function isBlank(node) {
    return !isVoid(node) && !isMeaningfulWhenBlank(node) && /^\s*$/i.test(node.textContent) && !hasVoid(node) && !hasMeaningfulWhenBlank(node);
  }
  function flankingWhitespace(node, options) {
    if (node.isBlock || options.preformattedCode && node.isCode) {
      return {
        leading: "",
        trailing: ""
      };
    }
    var edges = edgeWhitespace(node.textContent);
    if (edges.leadingAscii && isFlankedByWhitespace("left", node, options)) {
      edges.leading = edges.leadingNonAscii;
    }
    if (edges.trailingAscii && isFlankedByWhitespace("right", node, options)) {
      edges.trailing = edges.trailingNonAscii;
    }
    return {
      leading: edges.leading,
      trailing: edges.trailing
    };
  }
  function edgeWhitespace(string) {
    var m = string.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);
    return {
      leading: m[1],
      // whole string for whitespace-only strings
      leadingAscii: m[2],
      leadingNonAscii: m[3],
      trailing: m[4],
      // empty for whitespace-only strings
      trailingNonAscii: m[5],
      trailingAscii: m[6]
    };
  }
  function isFlankedByWhitespace(side, node, options) {
    var sibling;
    var regExp;
    var isFlanked;
    if (side === "left") {
      sibling = node.previousSibling;
      regExp = / $/;
    } else {
      sibling = node.nextSibling;
      regExp = /^ /;
    }
    if (sibling) {
      if (sibling.nodeType === 3) {
        isFlanked = regExp.test(sibling.nodeValue);
      } else if (options.preformattedCode && sibling.nodeName === "CODE") {
        isFlanked = false;
      } else if (sibling.nodeType === 1 && !isBlock(sibling)) {
        isFlanked = regExp.test(sibling.textContent);
      }
    }
    return isFlanked;
  }
  var reduce = Array.prototype.reduce;
  function TurndownService(options) {
    if (!(this instanceof TurndownService)) return new TurndownService(options);
    var defaults = {
      rules,
      headingStyle: "setext",
      hr: "* * *",
      bulletListMarker: "*",
      codeBlockStyle: "indented",
      fence: "```",
      emDelimiter: "_",
      strongDelimiter: "**",
      linkStyle: "inlined",
      linkReferenceStyle: "full",
      br: "  ",
      preformattedCode: false,
      blankReplacement: function(content, node) {
        return node.isBlock ? "\n\n" : "";
      },
      keepReplacement: function(content, node) {
        return node.isBlock ? "\n\n" + node.outerHTML + "\n\n" : node.outerHTML;
      },
      defaultReplacement: function(content, node) {
        return node.isBlock ? "\n\n" + content + "\n\n" : content;
      }
    };
    this.options = extend({}, defaults, options);
    this.rules = new Rules(this.options);
  }
  TurndownService.prototype = {
    /**
     * The entry point for converting a string or DOM node to Markdown
     * @public
     * @param {String|HTMLElement} input The string or DOM node to convert
     * @returns A Markdown representation of the input
     * @type String
     */
    turndown: function(input) {
      if (!canConvert(input)) {
        throw new TypeError(input + " is not a string, or an element/document/fragment node.");
      }
      if (input === "") return "";
      var output = process.call(this, new RootNode(input, this.options));
      return postProcess.call(this, output);
    },
    /**
     * Add one or more plugins
     * @public
     * @param {Function|Array} plugin The plugin or array of plugins to add
     * @returns The Turndown instance for chaining
     * @type Object
     */
    use: function(plugin) {
      if (Array.isArray(plugin)) {
        for (var i = 0; i < plugin.length; i++) this.use(plugin[i]);
      } else if (typeof plugin === "function") {
        plugin(this);
      } else {
        throw new TypeError("plugin must be a Function or an Array of Functions");
      }
      return this;
    },
    /**
     * Adds a rule
     * @public
     * @param {String} key The unique key of the rule
     * @param {Object} rule The rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    addRule: function(key, rule) {
      this.rules.add(key, rule);
      return this;
    },
    /**
     * Keep a node (as HTML) that matches the filter
     * @public
     * @param {String|Array|Function} filter The unique key of the rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    keep: function(filter) {
      this.rules.keep(filter);
      return this;
    },
    /**
     * Remove a node that matches the filter
     * @public
     * @param {String|Array|Function} filter The unique key of the rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    remove: function(filter) {
      this.rules.remove(filter);
      return this;
    },
    /**
     * Escapes Markdown syntax
     * @public
     * @param {String} string The string to escape
     * @returns A string with Markdown syntax escaped
     * @type String
     */
    escape: function(string) {
      return escapeMarkdown(string);
    }
  };
  function process(parentNode) {
    var self = this;
    return reduce.call(parentNode.childNodes, function(output, node) {
      node = new Node2(node, self.options);
      var replacement = "";
      if (node.nodeType === 3) {
        replacement = node.isCode ? node.nodeValue : self.escape(node.nodeValue);
      } else if (node.nodeType === 1) {
        replacement = replacementForNode.call(self, node);
      }
      return join(output, replacement);
    }, "");
  }
  function postProcess(output) {
    var self = this;
    this.rules.forEach(function(rule) {
      if (typeof rule.append === "function") {
        output = join(output, rule.append(self.options));
      }
    });
    return output.replace(/^[\t\r\n]+/, "").replace(/[\t\r\n\s]+$/, "");
  }
  function replacementForNode(node) {
    var rule = this.rules.forNode(node);
    var content = process.call(this, node);
    var whitespace = node.flankingWhitespace;
    if (whitespace.leading || whitespace.trailing) content = content.trim();
    return whitespace.leading + rule.replacement(content, node, this.options) + whitespace.trailing;
  }
  function join(output, replacement) {
    var s1 = trimTrailingNewlines(output);
    var s2 = trimLeadingNewlines(replacement);
    var nls = Math.max(output.length - s1.length, replacement.length - s2.length);
    var separator = "\n\n".substring(0, nls);
    return s1 + separator + s2;
  }
  function canConvert(input) {
    return input != null && (typeof input === "string" || input.nodeType && (input.nodeType === 1 || input.nodeType === 9 || input.nodeType === 11));
  }

  // shared/model.ts
  var COLORS = ["yellow", "green", "blue", "pink"];
  function checkedImage(input) {
    const value = input;
    if (!value || typeof value.url !== "string" || value.url.length > 1e4 || typeof value.alt !== "string" || value.alt.length > 2e3) throw new Error("\u56FE\u7247\u4FE1\u606F\u65E0\u6548");
    const url = new URL(value.url);
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) throw new Error("\u6682\u65F6\u53EA\u652F\u6301 HTTP / HTTPS \u56FE\u7247\u94FE\u63A5");
    if (value.data !== void 0 && (typeof value.data !== "string" || value.data.length > 16 * 1024 * 1024 + 64 || !/^data:image\/(?:png|jpeg|gif|webp|avif|svg\+xml|bmp|x-icon);base64,[A-Za-z0-9+/]+=*$/.test(value.data))) throw new Error("\u56FE\u7247\u9644\u4EF6\u683C\u5F0F\u65E0\u6548\u6216\u8D85\u8FC7 12 MB");
    return { url: url.href, alt: value.alt, ...value.data ? { data: value.data } : {} };
  }
  var DEFAULT_SETTINGS = {
    outputTarget: "obsidian",
    flomoApiUrl: "",
    recordHistory: false,
    excludedDomains: [],
    vaultName: "",
    vaultFolder: "Reading"
  };
  function publicationDate(value) {
    if (typeof value !== "string") return;
    const match = /^(\d{4}-\d{2}-\d{2})(?:$|[T\s]\d{2}:)/.exec(value.trim());
    if (!match) return;
    const day = /* @__PURE__ */ new Date(match[1] + "T00:00:00Z");
    if (Number.isFinite(day.getTime()) && day.toISOString().startsWith(match[1])) return match[1];
  }
  function normalizeUrl(value) {
    const url = new URL(value);
    if (!["http:", "https:"].includes(url.protocol)) throw new Error("\u4EC5\u652F\u6301 HTTP / HTTPS \u7F51\u9875");
    for (const key of [...url.searchParams.keys()]) {
      if (/^(utm_.+|fbclid|gclid|msclkid)$/i.test(key)) url.searchParams.delete(key);
    }
    return url.href;
  }
  function localDay(date = /* @__PURE__ */ new Date()) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }
  function obsidianUrl(settings2, id) {
    const params = new URLSearchParams({ vault: settings2.vaultName });
    const file = id ? `Articles/${id}.md` : "\u5361\u7247\u76D2.md";
    params.set("file", [settings2.vaultFolder.replace(/^\/+|\/+$/g, ""), file].filter(Boolean).join("/"));
    return `obsidian://open?${params}`;
  }

  // browser/src/capture.ts
  function captureArticle(source) {
    const clone = source.cloneNode(true);
    clone.querySelectorAll("[data-noting-root]").forEach((node) => node.remove());
    const article2 = new import_readability.Readability(clone).parse();
    const publishedDate2 = publicationDate(article2?.publishedTime) || publicationDate(source.querySelector('meta[property="article:published_time"], meta[itemprop="datePublished"]')?.getAttribute("content")) || publicationDate(source.querySelector('time[itemprop="datePublished"], article header time[datetime], time[pubdate]')?.getAttribute("datetime"));
    if (!article2?.content) return { bodyText: "", bodyMarkdown: "", publishedDate: publishedDate2 };
    const body = new DOMParser().parseFromString(article2.content, "text/html");
    body.querySelectorAll("script, style, iframe, form, input, button, svg, audio, video, img").forEach((node) => node.remove());
    for (const link of body.querySelectorAll("a")) {
      try {
        const url = new URL(link.getAttribute("href") || "", source.URL);
        if (!["http:", "https:"].includes(url.protocol)) throw new Error("Unsupported link");
        link.setAttribute("href", url.href);
      } catch {
        link.replaceWith(...link.childNodes);
      }
    }
    const converter = new TurndownService({ headingStyle: "atx", codeBlockStyle: "fenced", bulletListMarker: "-" });
    const paragraphs = [...body.querySelectorAll("h1, h2, h3, h4, h5, h6, p, pre, li, blockquote")].filter((node) => !node.parentElement?.closest("pre, li, blockquote")).map((node) => node.textContent?.trim()).filter(Boolean);
    return {
      publishedDate: publishedDate2,
      bodyText: (paragraphs.join("\n\n") || article2.textContent || "").slice(0, 1e6),
      bodyMarkdown: converter.turndown(body.body).slice(0, 1e6)
    };
  }

  // browser/src/anchors.ts
  function buildTextIndex(root2) {
    const entries = [];
    let text = "";
    const walker = document.createTreeWalker(root2, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent || parent.closest('script, style, noscript, textarea, input, select, [contenteditable]:not([contenteditable="false"]), [data-noting-root], [hidden], [aria-hidden="true"]')) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    while (walker.nextNode()) {
      const node = walker.currentNode;
      entries.push({ node, start: text.length, end: text.length + node.length });
      text += node.data;
    }
    return { text, entries };
  }
  function anchorFromRange(range, index) {
    const selected = index.entries.filter((entry) => range.intersectsNode(entry.node));
    if (!selected.length) return null;
    const first = selected[0];
    const last = selected[selected.length - 1];
    const start = first.start + (range.startContainer === first.node ? range.startOffset : 0);
    const end = last.start + (range.endContainer === last.node ? range.endOffset : last.node.length);
    const exact = index.text.slice(start, end);
    if (!exact.trim() || exact.length > 5e4) return null;
    return { exact, prefix: index.text.slice(Math.max(0, start - 48), start), suffix: index.text.slice(end, end + 48), start, end };
  }
  function locateText(text, anchor) {
    const positions = [];
    let position = text.indexOf(anchor.exact);
    while (position !== -1) {
      positions.push(position);
      position = text.indexOf(anchor.exact, position + 1);
    }
    if (positions.length === 1) return positions[0];
    const contextual = positions.filter(
      (start) => (!anchor.prefix || text.slice(Math.max(0, start - anchor.prefix.length), start) === anchor.prefix) && (!anchor.suffix || text.slice(start + anchor.exact.length, start + anchor.exact.length + anchor.suffix.length) === anchor.suffix)
    );
    if (contextual.length === 1) return contextual[0];
    return null;
  }
  function rangeFromAnchor(anchor, index) {
    const start = locateText(index.text, anchor);
    if (start === null) return null;
    const end = start + anchor.exact.length;
    const first = index.entries.find((entry) => entry.start <= start && entry.end > start);
    const last = index.entries.find((entry) => entry.start < end && entry.end >= end);
    if (!first || !last) return null;
    const range = document.createRange();
    range.setStart(first.node, start - first.start);
    range.setEnd(last.node, end - last.start);
    return range;
  }

  // browser/src/rpc.ts
  async function rpc(message) {
    const result = await chrome.runtime.sendMessage(message);
    if (!result?.ok) throw new Error(result?.error || "\u6269\u5C55\u8FDE\u63A5\u5DF2\u65AD\u5F00\uFF0C\u8BF7\u5237\u65B0\u7F51\u9875\u540E\u91CD\u8BD5\u3002");
    return result.data;
  }

  // browser/src/content.css
  var content_default = ':host { all: initial; color-scheme: light; font: 14px/1.6 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color: #282b32; }\n* { box-sizing: border-box; }\nbutton, textarea, a { font: inherit; }\nbutton { border: 0; cursor: pointer; color: inherit; background: transparent; border-radius: 7px; }\nbutton:focus-visible, a:focus-visible, textarea:focus-visible { outline: 2px solid #657956; outline-offset: 3px; }\nbutton:disabled { opacity: .5; cursor: wait; }\nbutton:hover { background: #f0f0eb; }\n[hidden] { display: none !important; }\na { color: #596d4b; text-decoration: none; }\na:hover { text-decoration: underline; }\n.toolbar { position: fixed; z-index: 2147483647; display: flex; align-items: center; gap: 7px; padding: 8px; background: #fffefb; border: 1px solid #e5e5dc; border-radius: 12px; box-shadow: 0 5px 24px #242b2530; }\n.toolbar .toolbar-label { padding-left: 4px; color: #62665e; font-size: 13px; white-space: nowrap; }\n.toolbar .divider { height: 23px; width: 1px; background: #e7e8e0; margin: 0 2px; }\n.toolbar button { padding: 5px 8px; white-space: nowrap; }\n.toolbar .color { width: 25px; height: 25px; padding: 0; border: 2px solid #fff; box-shadow: 0 0 0 1px #dfdfd5; border-radius: 50%; }\n.color[data-color="yellow"] { background: #f5d66d; }\n.color[data-color="green"] { background: #b4d6a4; }\n.color[data-color="blue"] { background: #a9cfee; }\n.color[data-color="pink"] { background: #eeb9c8; }\n.color[aria-pressed="true"] { box-shadow: 0 0 0 2px #4b6240; }\n.editor { position: fixed; width: min(350px, calc(100vw - 24px)); z-index: 2147483647; background: #fffefb; padding: 18px; border: 1px solid #e3e4db; border-radius: 14px; box-shadow: 0 12px 50px #242b2526; }\n.editor header, .panel header { display: flex; align-items: center; justify-content: space-between; gap: 12px; }\n.editor h3 { margin: 0; font-size: 15px; font-weight: 600; }\n.image-preview { margin: 12px 0; }\n.image-preview img { display: block; max-width: 100%; max-height: 180px; margin: auto; object-fit: contain; border-radius: 6px; }\n.editor { max-height: calc(100vh - 16px); overflow-y: auto; }\ntextarea { width: 100%; display: block; resize: vertical; min-height: 110px; padding: 11px 12px; border: 1px solid #dedfd5; border-radius: 8px; background: white; color: #282b32; line-height: 1.7; }\n.editor .colors { display: flex; gap: 9px; margin: 12px 0; }\n.editor .color { width: 20px; height: 20px; border-radius: 50%; }\n.actions { display: flex; gap: 8px; align-items: center; justify-content: flex-end; margin-top: 14px; }\n.actions button { padding: 7px 12px; }\n.primary { background: #526647; color: #fff; }\n.primary:hover { background: #3f5335; }\n.danger { color: #a35348; }\n.muted { color: #818278; font-size: 12px; }\n.note-hint { margin: 0 0 8px; line-height: 1.7; }\n.panel { position: fixed; inset: 0 0 0 auto; width: min(360px, 100vw); z-index: 2147483646; background: #f9faf6; border-left: 1px solid #e2e4d9; box-shadow: -12px 0 40px #1e2a1710; display: flex; flex-direction: column; }\n.panel > header { padding: 19px 22px; border-bottom: 1px solid #e5e7de; }\n.brand { font-size: 19px; letter-spacing: -.7px; font-weight: 650; }\n.brand span { color: #728263; font-size: 13px; font-weight: 500; letter-spacing: 0; }\n.panel header button { padding: 4px 8px; }\n.panel main { flex: 1; overflow: auto; padding: 24px 22px; }\n.eyebrow { font-size: 11px; color: #7b8174; letter-spacing: .08em; }\n.panel h1 { font-size: 19px; line-height: 1.55; letter-spacing: -.3px; margin: 8px 0 9px; font-weight: 600; overflow-wrap: anywhere; }\n.section-head { display: flex; align-items: center; justify-content: space-between; margin: 27px 0 11px; font-size: 13px; font-weight: 600; }\n.section-head span { color: #8e9386; font-weight: 400; }\n.page-note { min-height: 90px; font-size: 13px; }\n.note-view { position: relative; padding-right: 30px; }\n.note-text { margin: 0; white-space: pre-wrap; overflow-wrap: anywhere; line-height: 1.8; }\n.note-view .edit-note { position: absolute; top: 0; right: 0; display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; padding: 5px; color: #728263; }\n.edit-note svg { width: 16px; height: 16px; fill: none; stroke: currentColor; stroke-width: 1.6; stroke-linecap: round; stroke-linejoin: round; }\n.page-note-content { font-size: 13px; }\n.editor .note-view { margin-top: 14px; }\n.page-note-actions { margin-top: 8px; }\n.panel .page-note-actions .save-page { margin-top: 0; }\n.panel .save-page { margin-top: 8px; padding: 6px 12px; font-size: 12px; }\n.empty { color: #85897d; font-size: 13px; padding: 22px 4px; line-height: 1.9; }\n.card { margin: 12px 0; border: 1px solid #e3e6dc; background: #fff; border-radius: 10px; padding: 15px; }\n.card .quote { width: 100%; text-align: left; padding: 0 0 0 10px; border-left: 3px solid var(--highlight); border-radius: 0; line-height: 1.8; white-space: pre-wrap; overflow-wrap: anywhere; font-size: 13px; }\n.card .note { margin: 12px 0 0; font-size: 13px; white-space: pre-wrap; color: #6b7262; overflow-wrap: anywhere; }\n.card footer { display: flex; align-items: center; justify-content: space-between; margin-top: 12px; gap: 6px; }\n.card footer button { font-size: 12px; padding: 3px 7px; }\n.unresolved { color: #a57a3f; font-size: 11px; }\n.panel > footer { padding: 15px 22px; border-top: 1px solid #e5e7de; display: flex; flex-wrap: wrap; gap: 10px 14px; align-items: center; font-size: 12px; }\n.panel > footer button { padding: 0; font-size: 12px; color: #767e6c; }\n.output-status { flex-basis: 100%; font-size: 11px; line-height: 1.7; color: #65765a; }\n.connect-obsidian { color: #526647; font-size: 12px; margin-top: 10px; }\n.toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); max-width: min(560px, calc(100vw - 40px)); padding: 11px 18px; border-radius: 9px; background: #303b29; color: white; z-index: 2147483647; box-shadow: 0 4px 22px #0002; font-size: 13px; }\n.toast.error { background: #8b483e; }\n@media (prefers-reduced-motion: no-preference) { .card { transition: background .15s; } }\n';

  // browser/src/content.ts
  var highlightColors = { yellow: "#f8df83", green: "#c3dfad", blue: "#bbdaf2", pink: "#f1c3d0" };
  var host = document.createElement("div");
  host.dataset.notingRoot = "";
  host.id = "noting-extension";
  var shadow = host.attachShadow({ mode: "closed" });
  for (const type of ["click", "dblclick", "keydown", "keypress", "keyup", "input", "pointerdown"]) {
    shadow.addEventListener(type, (event) => {
      if (!event.isTrusted) event.stopImmediatePropagation();
    }, { capture: true });
  }
  var style = document.createElement("style");
  style.textContent = content_default;
  shadow.append(style);
  for (const type of ["keydown", "keypress", "keyup"]) {
    shadow.addEventListener(type, (event) => {
      event.stopPropagation();
      const key = event;
      if (type === "keydown" && key.key === "Escape" && !key.isComposing) {
        toolbar.hidden = true;
        imageToolbar.hidden = true;
        closeEditor();
      }
    });
  }
  document.documentElement.append(host);
  var highlightStyle = document.createElement("style");
  highlightStyle.dataset.notingRoot = "";
  highlightStyle.textContent = COLORS.map((color) => `::highlight(noting-${color}) { background-color: ${highlightColors[color]}; color: #20251b; }`).join("\n");
  document.documentElement.append(highlightStyle);
  function element(tag, className = "", text = "") {
    const node = document.createElement(tag);
    node.className = className;
    node.textContent = text;
    return node;
  }
  function button(label, action, className = "") {
    const node = element("button", className, label);
    node.type = "button";
    node.addEventListener("click", () => {
      Promise.resolve(action()).catch((error) => toast(error instanceof Error ? error.message : String(error), true));
    });
    return node;
  }
  function noteView(text, label, edit, className = "") {
    const view = element("div", "note-view " + className);
    const content = element("p", "note-text" + (text ? "" : " muted"), text || "\u8FD8\u6CA1\u6709\u7B14\u8BB0\uFF0C\u53CC\u51FB\u8FD9\u91CC\u5F00\u59CB\u8BB0\u5F55\u3002");
    content.addEventListener("dblclick", edit);
    const pencil = button("", edit, "edit-note");
    pencil.setAttribute("aria-label", label);
    pencil.title = label;
    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    icon.setAttribute("viewBox", "0 0 24 24");
    icon.setAttribute("aria-hidden", "true");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", "m16 3 5 5-12 12-6 1 1-6L16 3Zm-2 2 5 5");
    icon.append(path);
    pencil.append(icon);
    view.append(content, pencil);
    return view;
  }
  var currentUrl = location.href;
  var article = null;
  var settings = DEFAULT_SETTINGS;
  var excluded = false;
  var ready = false;
  var panelOpen = false;
  var selectionAnchor = null;
  var selectionRect = null;
  var ranges = /* @__PURE__ */ new Map();
  var cachedBody;
  var publishedDate;
  var cachedMarkdown;
  var bodyAttempted = false;
  var pageDraft;
  var pageDraftBase;
  var pageEditing = false;
  var editorDraft = false;
  var selectedColor = "yellow";
  var savingSelection = false;
  var imageTarget = null;
  var renderTimer;
  var toastTimer;
  var awaitingSiyuanResult = false;
  var outputStatus;
  async function refreshOutputStatus(announce = false) {
    const url = currentUrl;
    const state = await rpc({ type: "PAGE_OUTPUT_STATUS", page: page() });
    if (url !== currentUrl) {
      awaitingSiyuanResult = false;
      return;
    }
    if (announce && state.target === "siyuan") awaitingSiyuanResult = true;
    outputStatus = state;
    if (panelOpen) renderPanel();
    if (state.target === "siyuan") {
      if (awaitingSiyuanResult && (state.error || !state.connected || !state.pending)) {
        awaitingSiyuanResult = false;
        toast(outputMessage(), Boolean(state.error));
      }
    } else {
      awaitingSiyuanResult = false;
      if (announce) toast(outputMessage(), Boolean(state.error));
    }
  }
  function outputMessage() {
    if (outputStatus?.target === "siyuan") {
      if (outputStatus.error) return "\u601D\u6E90\u5199\u5165\u9700\u8981\u5904\u7406\uFF1A" + outputStatus.error;
      if (!outputStatus.connected) return "\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668\uFF1B\u8BF7\u914D\u7F6E\u601D\u6E90\u7B14\u8BB0";
      if (outputStatus.pending) return "\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668";
      return outputStatus.sent ? "\u5DF2\u5199\u5165\u601D\u6E90" : "\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668\uFF1B\u65B0\u589E\u6216\u4FEE\u6539\u7B14\u8BB0\u540E\u5199\u5165\u601D\u6E90";
    }
    if (outputStatus?.target === "flomo") {
      if (outputStatus.error) return "flomo \u5199\u5165\u9700\u8981\u5904\u7406\uFF1A" + outputStatus.error;
      if (!outputStatus.connected) return "\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668\uFF1B\u8BF7\u914D\u7F6E flomo API URL";
      if (outputStatus.pending) return "\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668\uFF0C\u7B49\u5F85\u5199\u5165 flomo";
      return outputStatus.sent ? "\u5DF2\u5199\u5165 flomo" : "\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668\uFF1B\u65B0\u589E\u6216\u4FEE\u6539\u7B14\u8BB0\u540E\u5199\u5165 flomo";
    }
    if (!outputStatus?.connected) return "\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668\uFF1B\u8FDE\u63A5\u7B14\u8BB0\u6587\u4EF6\u5939\u540E\u53EF\u81EA\u52A8\u5199\u5165";
    if (outputStatus.error) return "\u540C\u6B65\u9700\u8981\u5904\u7406\uFF1A" + outputStatus.error;
    if (outputStatus.pending) return "\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668\uFF0C\u6B63\u5728\u7B49\u5F85\u5199\u5165\u7B14\u8BB0\u6587\u4EF6\u5939";
    return `\u5DF2\u5199\u5165\u7B14\u8BB0\u6587\u4EF6\u5939 \xB7 ${outputStatus.vaultName}`;
  }
  var toolbar = element("div", "toolbar");
  toolbar.hidden = true;
  toolbar.setAttribute("role", "toolbar");
  toolbar.setAttribute("aria-label", "\u5212\u7EBF\u5DE5\u5177");
  toolbar.addEventListener("pointerdown", (event) => event.preventDefault());
  for (const color of COLORS) {
    const node = button("", async () => {
      await saveSelection(color);
    }, "color");
    node.dataset.color = color;
    node.setAttribute("aria-label", { yellow: "\u9EC4\u8272\u5212\u7EBF", green: "\u7EFF\u8272\u5212\u7EBF", blue: "\u84DD\u8272\u5212\u7EBF", pink: "\u7C89\u8272\u5212\u7EBF" }[color]);
    node.title = node.getAttribute("aria-label");
    toolbar.append(node);
  }
  toolbar.append(element("span", "divider"));
  toolbar.append(button("\u8BB0\u7B14\u8BB0", () => {
    if (!selectionAnchor) return;
    openEditor({ id: "h_" + crypto.randomUUID(), anchor: selectionAnchor, color: selectedColor, note: "", createdAt: "", updatedAt: "" }, selectionRect);
  }));
  toolbar.append(button("\u2630", () => togglePanel(true)));
  toolbar.lastElementChild.setAttribute("aria-label", "\u67E5\u770B\u672C\u9875\u7B14\u8BB0");
  var imageToolbar = element("div", "toolbar image-toolbar");
  imageToolbar.hidden = true;
  imageToolbar.setAttribute("role", "toolbar");
  imageToolbar.setAttribute("aria-label", "\u5212\u7EBF\u7B14\u8BB0\u56FE\u7247\u5DE5\u5177");
  imageToolbar.append(element("span", "toolbar-label", "\u5212\u7EBF\u7B14\u8BB0"), element("span", "divider"));
  var collectImage = button("\u6536\u5F55\u56FE\u7247", async () => {
    if (!imageTarget || savingSelection) return;
    const annotation = imageAnnotation(imageTarget);
    savingSelection = true;
    try {
      await persist(annotation);
    } finally {
      savingSelection = false;
    }
  });
  var openImageNote = button("\u8BB0\u7B14\u8BB0", () => {
    if (!imageTarget) return;
    const saved = savedImageAnnotation(imageTarget);
    openEditor(saved ?? imageAnnotation(imageTarget), imageTarget.getBoundingClientRect(), !saved?.note);
  });
  imageToolbar.append(collectImage, openImageNote);
  var editor = element("section", "editor");
  editor.hidden = true;
  editor.setAttribute("role", "dialog");
  editor.setAttribute("aria-label", "\u7F16\u8F91\u5212\u7EBF\u7B14\u8BB0");
  var panel = element("aside", "panel");
  panel.hidden = true;
  panel.setAttribute("aria-label", "\u5212\u7EBF\u7B14\u8BB0 / Underline Notes \u5F53\u524D\u6587\u7AE0");
  var notification = element("div", "toast");
  notification.hidden = true;
  notification.setAttribute("role", "status");
  shadow.append(toolbar, imageToolbar, editor, panel, notification);
  function imageAnnotation(image) {
    const reference = checkedImage({ url: image.currentSrc || image.src, alt: image.alt.slice(0, 2e3) });
    const exact = reference.alt.trim() || "\u7F51\u9875\u56FE\u7247";
    return { id: "h_" + crypto.randomUUID(), anchor: { exact, prefix: "", suffix: "", start: 0, end: exact.length }, image: reference, color: selectedColor, note: "", createdAt: "", updatedAt: "" };
  }
  function savedImageAnnotation(image) {
    const url = image.currentSrc || image.src;
    const matches = article?.annotations.filter((item) => item.image?.url === url).reverse();
    return matches?.find((item) => item.note.trim()) ?? matches?.[0];
  }
  function imagePreview(reference) {
    const figure = element("figure", "image-preview");
    const image = element("img");
    image.alt = reference.alt || "\u7F51\u9875\u56FE\u7247";
    image.referrerPolicy = "no-referrer";
    const fallback = element("a", "muted", "\u56FE\u7247\u65E0\u6CD5\u9884\u89C8\uFF0C\u6253\u5F00\u539F\u56FE \u2197");
    fallback.href = reference.url;
    fallback.target = "_blank";
    fallback.rel = "noopener noreferrer";
    fallback.hidden = true;
    image.addEventListener("error", () => {
      image.hidden = true;
      fallback.hidden = false;
    });
    image.src = reference.data || reference.url;
    figure.append(image, fallback);
    return figure;
  }
  function findImage(annotation) {
    return annotation.image ? [...document.images].find((image) => image.currentSrc === annotation.image.url || image.src === annotation.image.url) : void 0;
  }
  function toast(message, error = false) {
    notification.textContent = message;
    notification.className = "toast" + (error ? " error" : "");
    notification.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      notification.hidden = true;
    }, error ? 7e3 : 2500);
  }
  function page(withBody = false) {
    if (withBody && !bodyAttempted) {
      bodyAttempted = true;
      try {
        const captured = captureArticle(document);
        cachedBody = captured.bodyText;
        cachedMarkdown = captured.bodyMarkdown;
        publishedDate = captured.publishedDate;
      } catch {
        cachedBody = "";
        cachedMarkdown = "";
      }
    }
    return { url: currentUrl, publishedDate, title: document.title.slice(0, 2e3) || new URL(currentUrl).hostname, bodyText: withBody ? cachedBody : "", bodyMarkdown: withBody ? cachedMarkdown : "" };
  }
  async function refresh() {
    const url = currentUrl;
    const result = await rpc({ type: "GET_PAGE", page: page() });
    if (url !== currentUrl) return;
    article = result.article;
    settings = result.settings;
    excluded = result.excluded;
    ready = true;
    if (excluded) {
      toolbar.hidden = true;
      imageToolbar.hidden = true;
      editor.hidden = true;
    }
    restoreHighlights();
    if (panelOpen) renderPanel();
    void refreshOutputStatus().catch(() => void 0);
  }
  function restoreHighlights() {
    if (!CSS.highlights) return;
    ranges = /* @__PURE__ */ new Map();
    for (const color of COLORS) CSS.highlights.delete("noting-" + color);
    if (!article || excluded || !document.body) return;
    const index = buildTextIndex(document.body);
    const groups = Object.fromEntries(COLORS.map((color) => [color, new Highlight()]));
    for (const annotation of article.annotations) {
      if (annotation.image) continue;
      const range = rangeFromAnchor(annotation.anchor, index);
      if (range) {
        ranges.set(annotation.id, range);
        groups[annotation.color].add(range);
      }
    }
    for (const color of COLORS) CSS.highlights.set("noting-" + color, groups[color]);
  }
  function positionFloating(node, rect) {
    const width = node.offsetWidth;
    const height = node.offsetHeight;
    const left = rect ? rect.left + rect.width / 2 - width / 2 : innerWidth / 2 - width / 2;
    const above = (rect?.top ?? 100) - height - 10;
    const top = above >= 8 ? above : (rect?.bottom ?? 100) + 10;
    node.style.left = Math.max(8, Math.min(innerWidth - width - 8, left)) + "px";
    node.style.top = Math.max(8, Math.min(innerHeight - height - 8, top)) + "px";
  }
  async function persist(annotation, expectedNote = "") {
    const url = currentUrl;
    const result = await rpc({ type: "SAVE_ANNOTATION", page: page(true), annotation, expectedNote });
    if (url !== currentUrl) return;
    article = result;
    toolbar.hidden = true;
    imageToolbar.hidden = true;
    editor.hidden = true;
    editorDraft = false;
    window.getSelection()?.removeAllRanges();
    restoreHighlights();
    if (panelOpen) renderPanel();
    if (settings.outputTarget !== "siyuan") toast("\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668");
    void refreshOutputStatus(true).catch(() => void 0);
  }
  async function saveSelection(color) {
    if (!selectionAnchor || savingSelection) return;
    savingSelection = true;
    selectedColor = color;
    const annotation = { id: "h_" + crypto.randomUUID(), anchor: selectionAnchor, color, note: "", createdAt: "", updatedAt: "" };
    try {
      await persist(annotation);
      selectionAnchor = null;
    } finally {
      savingSelection = false;
    }
  }
  function closeEditor() {
    if (editorDraft && !window.confirm("\u8FD9\u6761\u7B14\u8BB0\u8FD8\u6CA1\u4FDD\u5B58\uFF0C\u653E\u5F03\u4FEE\u6539\uFF1F")) return false;
    editor.hidden = true;
    editorDraft = false;
    return true;
  }
  function openEditor(annotation, rect = null, editing = true) {
    if (!editor.hidden && !closeEditor()) return;
    toolbar.hidden = true;
    imageToolbar.hidden = true;
    editor.replaceChildren();
    const header = element("header");
    const label = annotation.image ? "\u56FE\u7247\u7B14\u8BB0" : "\u5212\u7EBF\u7B14\u8BB0";
    editor.setAttribute("aria-label", (editing ? "\u7F16\u8F91" : "\u67E5\u770B") + label);
    header.append(element("h3", "", label), button("\xD7", () => {
      closeEditor();
    }));
    header.lastElementChild.setAttribute("aria-label", "\u5173\u95ED\u7B14\u8BB0\u7F16\u8F91\u5668");
    if (!editing) {
      editor.append(header);
      if (annotation.image) editor.append(imagePreview(annotation.image));
      editor.append(noteView(annotation.note, "\u7F16\u8F91\u7B14\u8BB0", () => openEditor(annotation, rect)));
      editor.hidden = false;
      editorDraft = false;
      positionFloating(editor, rect);
      editor.querySelector(".edit-note")?.focus();
      return;
    }
    const input = element("textarea");
    input.placeholder = annotation.image ? "\u8FD9\u5F20\u56FE\u7247\u8868\u8FBE\u4E86\u4EC0\u4E48\uFF1F\u5199\u4E0B\u4F60\u7684\u7406\u89E3\u2026" : "\u53EF\u4EE5\u5148\u7528\u81EA\u5DF1\u7684\u8BDD\u590D\u8FF0\u539F\u6587\uFF0C\u518D\u8865\u5145\u7406\u89E3\u6216\u8BC4\u8BBA\u3002\u652F\u6301 Markdown\u3002";
    input.setAttribute("aria-label", label);
    input.value = annotation.note;
    input.addEventListener("input", () => {
      editorDraft = true;
    });
    let color = annotation.color;
    const colors = element("div", "colors");
    for (const option of COLORS) {
      const node = button("", () => {
        color = option;
        editorDraft = true;
        for (const child of colors.children) child.setAttribute("aria-pressed", String(child.dataset.color === color));
      }, "color");
      node.dataset.color = option;
      node.setAttribute("aria-label", option);
      node.setAttribute("aria-pressed", String(option === color));
      colors.append(node);
    }
    const actions = element("div", "actions");
    if (article?.annotations.some((item) => item.id === annotation.id)) {
      actions.append(button(annotation.image ? "\u5220\u9664\u56FE\u7247\u7B14\u8BB0" : "\u5220\u9664\u7B14\u8BB0", async () => {
        const target = annotation.image ? "\u8FD9\u6761\u56FE\u7247\u7B14\u8BB0" : "\u8FD9\u6761\u7B14\u8BB0\u53CA\u5BF9\u5E94\u7684\u5212\u7EBF";
        if (!window.confirm("\u786E\u5B9A\u5220\u9664" + target + (settings.outputTarget !== "obsidian" ? `\u5417\uFF1F${settings.outputTarget === "siyuan" ? "\u601D\u6E90" : "flomo"} \u4E2D\u5DF2\u5199\u5165\u7684\u8BB0\u5F55\u9700\u81EA\u884C\u5220\u9664\u3002` : "\u5417\uFF1F\u540C\u6B65\u65F6\u4E5F\u4F1A\u5220\u9664 Obsidian \u4E2D\u5BF9\u5E94\u7684\u5361\u7247\uFF0C\u5305\u62EC\u5361\u7247\u91CC\u8865\u5199\u7684\u5185\u5BB9\u3002"))) return;
        article = await rpc({ type: "DELETE_ANNOTATION", page: page(), id: annotation.id });
        editorDraft = false;
        closeEditor();
        restoreHighlights();
        if (panelOpen) renderPanel();
      }, "danger"));
    }
    const saveAnnotation = async () => {
      if (save.disabled) return;
      save.disabled = true;
      try {
        await persist({ ...annotation, color, note: input.value }, annotation.note);
      } finally {
        save.disabled = false;
      }
    };
    const save = button("\u4FDD\u5B58", saveAnnotation, "primary");
    input.addEventListener("keydown", (event) => {
      if (!event.isComposing && (event.ctrlKey || event.metaKey) && event.key === "Enter") {
        event.preventDefault();
        void saveAnnotation().catch((error) => toast(error instanceof Error ? error.message : String(error), true));
      }
    });
    actions.append(save);
    editor.append(header);
    if (annotation.image) {
      const hint = element("p", "muted note-hint", "\u4FDD\u5B58\u65F6\u4F1A\u4E00\u5E76\u6536\u5F55\u56FE\u7247\u3002\u6279\u6CE8\u652F\u6301 Markdown\u3002");
      hint.id = "highlight-note-hint";
      input.setAttribute("aria-describedby", hint.id);
      editor.append(imagePreview(annotation.image), hint);
    } else editor.append(colors);
    editor.append(input, actions);
    if (!outputStatus?.connected) editor.append(button(settings.outputTarget === "siyuan" ? "\u914D\u7F6E\u601D\u6E90\uFF0C\u5F00\u542F\u81EA\u52A8\u5199\u5165" : settings.outputTarget === "flomo" ? "\u914D\u7F6E flomo\uFF0C\u5F00\u542F\u81EA\u52A8\u5199\u5165" : "\u8FDE\u63A5\u7B14\u8BB0\u6587\u4EF6\u5939\uFF0C\u5F00\u542F\u81EA\u52A8\u5199\u5165", async () => {
      await rpc({ type: "OPEN_OPTIONS" });
    }, "connect-obsidian"));
    editor.hidden = false;
    editorDraft = false;
    positionFloating(editor, rect);
    input.focus();
  }
  function focusHighlight(annotation) {
    if (annotation.image) {
      const image = findImage(annotation);
      if (image) image.scrollIntoView({ block: "center", behavior: "smooth" });
      else toast("\u539F\u56FE\u4F4D\u7F6E\u5DF2\u53D8\u5316\uFF0C\u56FE\u7247\u5F15\u7528\u4ECD\u4FDD\u7559\u5728\u7B14\u8BB0\u4E2D\u3002", true);
      return;
    }
    const range = ranges.get(annotation.id);
    if (!range) {
      toast("\u539F\u6587\u4F4D\u7F6E\u5DF2\u53D8\u5316\uFF0C\u53EF\u5728\u7B14\u8BB0\u4E2D\u4FDD\u7559\u6458\u5F55\u3002", true);
      return;
    }
    const parent = range.startContainer.parentElement;
    parent?.scrollIntoView({ block: "center", behavior: "smooth" });
  }
  function renderPanel(focusNote = false) {
    const scrollTop = panel.querySelector("main")?.scrollTop ?? 0;
    const noteFocused = shadow.activeElement?.classList.contains("page-note");
    const selection = noteFocused ? [shadow.activeElement.selectionStart, shadow.activeElement.selectionEnd] : null;
    panel.replaceChildren();
    const header = element("header");
    const brand = element("div", "brand", "\u5212\u7EBF\u7B14\u8BB0");
    brand.append(element("span", "", " / Underline Notes"));
    header.append(brand, button("\xD7", () => togglePanel(false)));
    header.lastElementChild.setAttribute("aria-label", "\u5173\u95ED\u4FA7\u8FB9\u680F");
    const main = element("main");
    main.append(element("div", "eyebrow", new URL(currentUrl).hostname), element("h1", "", document.title));
    main.append(element("div", "muted", excluded ? "\u6B64\u7F51\u7AD9\u5DF2\u6682\u505C\u8BB0\u5F55" : settings.outputTarget === "siyuan" ? "\u672C\u9875\u7B14\u8BB0 \xB7 \u601D\u6E90" : settings.outputTarget === "flomo" ? "\u672C\u9875\u7B14\u8BB0 \xB7 flomo" : "\u672C\u9875\u7B14\u8BB0 \xB7 \u672C\u5730\u4FDD\u5B58"));
    if (excluded) {
      main.append(element("p", "empty", "\u53EF\u4EE5\u5728\u8BBE\u7F6E\u4E2D\u79FB\u9664\u6B64\u7F51\u7AD9\uFF0C\u6062\u590D\u5212\u7EBF\u548C\u9605\u8BFB\u8BB0\u5F55\u3002"));
    } else {
      main.append(element("div", "section-head", "\u6587\u7AE0\u7B14\u8BB0"));
      if (!pageEditing) {
        main.append(noteView(article?.pageNote ?? "", "\u7F16\u8F91\u6587\u7AE0\u7B14\u8BB0", () => {
          pageEditing = true;
          pageDraft = article?.pageNote ?? "";
          pageDraftBase = pageDraft;
          renderPanel(true);
        }, "page-note-content"));
      } else {
        const note = element("textarea", "page-note");
        note.value = pageDraft ?? article?.pageNote ?? "";
        note.placeholder = "\u8FD9\u7BC7\u6587\u7AE0\u7684\u4E3B\u8981\u89C2\u70B9\u662F\u4EC0\u4E48\uFF1F\u8BD5\u7740\u7528\u81EA\u5DF1\u7684\u8BDD\u6982\u62EC\u2026";
        note.setAttribute("aria-label", "\u6587\u7AE0\u7B14\u8BB0");
        note.setAttribute("aria-describedby", "page-note-hint");
        const hint = element("p", "muted note-hint", "\u53EF\u4EE5\u5148\u590D\u8FF0\u6587\u7AE0\u7684\u8981\u70B9\uFF0C\u518D\u8BB0\u4E0B\u81EA\u5DF1\u7684\u7406\u89E3\u6216\u8BC4\u8BBA\u3002");
        hint.id = "page-note-hint";
        note.addEventListener("input", () => {
          if (pageDraft === void 0) pageDraftBase = article?.pageNote ?? "";
          pageDraft = note.value;
        });
        const savePageNote = async () => {
          if (saveNote.disabled) return;
          saveNote.disabled = true;
          try {
            article = await rpc({ type: "SAVE_PAGE_NOTE", page: page(true), note: note.value, expectedNote: pageDraftBase ?? article?.pageNote ?? "" });
            pageDraft = void 0;
            pageDraftBase = void 0;
            pageEditing = false;
            if (settings.outputTarget !== "siyuan") toast("\u6587\u7AE0\u7B14\u8BB0\u5DF2\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668");
            void refreshOutputStatus(true).catch(() => void 0);
            renderPanel();
          } finally {
            saveNote.disabled = false;
          }
        };
        const saveNote = button("\u4FDD\u5B58\u6587\u7AE0\u7B14\u8BB0", savePageNote, "primary save-page");
        const cancelNote = button("\u53D6\u6D88", () => {
          if (pageDraft !== pageDraftBase && !window.confirm("\u6587\u7AE0\u7B14\u8BB0\u8FD8\u6CA1\u4FDD\u5B58\uFF0C\u653E\u5F03\u4FEE\u6539\uFF1F")) return;
          pageDraft = void 0;
          pageDraftBase = void 0;
          pageEditing = false;
          renderPanel();
        });
        note.addEventListener("keydown", (event) => {
          if (!event.isComposing && (event.ctrlKey || event.metaKey) && event.key === "Enter") {
            event.preventDefault();
            void savePageNote().catch((error) => toast(error instanceof Error ? error.message : String(error), true));
          }
        });
        const actions = element("div", "actions page-note-actions");
        actions.append(cancelNote, saveNote);
        main.append(hint, note, actions);
        if (pageDraft !== void 0 && pageDraftBase !== (article?.pageNote ?? "")) {
          main.append(element("p", "muted", "\u6587\u7AE0\u7B14\u8BB0\u5DF2\u6709\u65B0\u7248\u672C\uFF0C\u4F60\u7684\u8349\u7A3F\u4ECD\u4FDD\u7559\u5728\u4E0A\u65B9\u3002\u8BF7\u5148\u590D\u5236\u9700\u8981\u4FDD\u7559\u7684\u5185\u5BB9\uFF0C\u518D\u8F7D\u5165\u6700\u65B0\u7248\u672C\u5408\u5E76\u3002"));
          main.append(button("\u8F7D\u5165\u6700\u65B0\u6587\u7AE0\u7B14\u8BB0", async () => {
            if (!window.confirm("\u5DF2\u590D\u5236\u8981\u4FDD\u7559\u7684\u8349\u7A3F\uFF1F\u8F7D\u5165\u6700\u65B0\u7248\u672C\u4F1A\u66FF\u6362\u5F53\u524D\u8F93\u5165\u3002")) return;
            pageDraft = void 0;
            pageDraftBase = void 0;
            await refresh();
          }));
        }
      }
      const heading = element("div", "section-head", "\u6458\u5F55\u4E0E\u6279\u6CE8");
      heading.append(element("span", "", String(article?.annotations.length ?? 0)));
      main.append(heading);
      if (!article?.annotations.length) main.append(element("p", "empty", "\u9009\u4E2D\u6587\u5B57\u5212\u7EBF\uFF0C\u6216\u5C06\u9F20\u6807\u79FB\u5230\u56FE\u7247\u4E0A\u6536\u5F55\u56FE\u7247\u3001\u8BB0\u7B14\u8BB0\u3002\n\u4F60\u7684\u6458\u5F55\u4E0E\u60F3\u6CD5\u4F1A\u51FA\u73B0\u5728\u8FD9\u91CC\u3002"));
      for (const annotation of article?.annotations ?? []) {
        const card = element("article", "card");
        card.dataset.annotationId = annotation.id;
        card.style.setProperty("--highlight", highlightColors[annotation.color]);
        card.append(button(annotation.anchor.exact, () => focusHighlight(annotation), "quote"));
        if (annotation.image) card.append(imagePreview(annotation.image));
        card.append(noteView(annotation.note, annotation.note ? "\u7F16\u8F91\u7B14\u8BB0" : "\u6DFB\u52A0\u7B14\u8BB0", () => openEditor(annotation, null), "note"));
        const footer2 = element("footer");
        const resolved = annotation.image ? Boolean(findImage(annotation)) : ranges.has(annotation.id);
        footer2.append(element("span", resolved ? "muted" : "unresolved", resolved ? annotation.image ? "\u70B9\u51FB\u6807\u9898\u5B9A\u4F4D\u539F\u56FE" : "\u70B9\u51FB\u6458\u5F55\u5B9A\u4F4D\u539F\u6587" : "\u539F\u6587\u4F4D\u7F6E\u5F85\u91CD\u65B0\u5B9A\u4F4D"));
        card.append(footer2);
        main.append(card);
      }
      if (article) main.append(button("\u79FB\u9664\u672C\u9875\u8BB0\u5F55", async () => {
        if (!window.confirm(settings.outputTarget !== "obsidian" ? `\u79FB\u9664\u672C\u9875\u5212\u7EBF\u3001\u7B14\u8BB0\u548C\u9605\u8BFB\u8BB0\u5F55\uFF1F${settings.outputTarget === "siyuan" ? "\u601D\u6E90" : "flomo"} \u4E2D\u5DF2\u5199\u5165\u7684\u8BB0\u5F55\u9700\u81EA\u884C\u5220\u9664\u3002` : "\u79FB\u9664\u672C\u9875\u5212\u7EBF\u3001\u7B14\u8BB0\u548C\u9605\u8BFB\u8BB0\u5F55\uFF1F\u540C\u6B65\u65F6\u4E5F\u4F1A\u5220\u9664 Obsidian \u4E2D\u672C\u9875\u7684\u7B14\u8BB0\u5361\u7247\uFF0C\u5305\u62EC\u5361\u7247\u91CC\u8865\u5199\u7684\u5185\u5BB9\u3002")) return;
        await rpc({ type: "DELETE_ARTICLE", page: page() });
        article = null;
        pageDraft = void 0;
        pageDraftBase = void 0;
        pageEditing = false;
        restoreHighlights();
        renderPanel();
      }, "danger"));
    }
    const footer = element("footer");
    if (article) footer.append(element("span", "output-status", outputMessage()));
    if (settings.outputTarget === "siyuan") {
      if (outputStatus?.docId) {
        const link = element("a", "", "\u5728\u601D\u6E90\u56DE\u987E \u2197");
        link.href = `siyuan://blocks/${outputStatus.docId}`;
        footer.append(link);
      } else footer.append(button("\u914D\u7F6E\u601D\u6E90\u7B14\u8BB0", async () => {
        await rpc({ type: "OPEN_OPTIONS" });
      }));
    } else if (settings.outputTarget === "flomo") {
      const link = element("a", "", "\u5728 flomo \u56DE\u987E \u2197");
      link.href = "https://v.flomoapp.com/";
      link.target = "_blank";
      link.rel = "noreferrer";
      footer.append(link);
    } else if (outputStatus?.connected && settings.vaultName) {
      const link = element("a", "", "\u5728 Obsidian \u56DE\u987E \u2197");
      link.href = obsidianUrl(settings, article?.id);
      footer.append(link);
    } else footer.append(button("\u8FDE\u63A5\u7B14\u8BB0\u6587\u4EF6\u5939\uFF0C\u5F00\u542F\u81EA\u52A8\u5199\u5165", async () => {
      await rpc({ type: "OPEN_OPTIONS" });
    }, "connect-obsidian"));
    footer.append(button("\u8BBE\u7F6E\u4E0E\u6587\u4EF6\u5199\u5165", async () => {
      await rpc({ type: "OPEN_OPTIONS" });
    }));
    panel.append(header, main, footer);
    main.scrollTop = scrollTop;
    const input = main.querySelector("textarea");
    if (input && (focusNote || noteFocused && selection)) {
      input.focus();
      if (selection) input.setSelectionRange(selection[0], selection[1]);
    }
  }
  function togglePanel(open = !panelOpen) {
    panelOpen = open;
    panel.hidden = !open;
    if (open) {
      renderPanel();
      void refresh().catch((error) => toast(error.message, true));
    }
  }
  function inspectSelection() {
    if (!ready || excluded || !editor.hidden) return;
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) {
      toolbar.hidden = true;
      return;
    }
    const range = selection.getRangeAt(0);
    if (range.commonAncestorContainer.getRootNode() !== document) return;
    const container = range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
    if (container?.closest('input, textarea, [contenteditable]:not([contenteditable="false"])')) return;
    selectionAnchor = anchorFromRange(range, buildTextIndex(document.body));
    if (!selectionAnchor) return;
    imageToolbar.hidden = true;
    selectionRect = range.getBoundingClientRect();
    toolbar.hidden = false;
    positionFloating(toolbar, selectionRect);
  }
  document.addEventListener("mouseover", (event) => {
    if (!ready || excluded || !editor.hidden || event.composedPath().includes(host)) return;
    const target = event.target;
    if (!(target instanceof HTMLImageElement) || target.closest('[contenteditable]:not([contenteditable="false"])')) return;
    const rect = target.getBoundingClientRect();
    if (rect.width < 48 || rect.height < 48 || !target.currentSrc && !target.src) return;
    imageTarget = target;
    const saved = savedImageAnnotation(target);
    collectImage.disabled = Boolean(saved);
    collectImage.textContent = saved ? "\u5DF2\u6536\u5F55" : "\u6536\u5F55\u56FE\u7247";
    openImageNote.textContent = saved?.note ? "\u67E5\u770B\u7B14\u8BB0" : "\u8BB0\u7B14\u8BB0";
    toolbar.hidden = true;
    imageToolbar.hidden = false;
    positionFloating(imageToolbar, rect);
  });
  document.addEventListener("mouseup", (event) => {
    if (!event.composedPath().includes(host)) setTimeout(inspectSelection, 0);
  });
  document.addEventListener("keyup", (event) => {
    if (event.key.startsWith("Arrow") && event.shiftKey) inspectSelection();
  });
  function dismissOutside(event) {
    if (!event.isTrusted) return;
    const path = event.composedPath();
    if (!path.includes(imageToolbar)) imageToolbar.hidden = true;
    if (path.includes(editor)) return;
    if (!editor.hidden && !closeEditor()) return;
    if (panelOpen && !path.includes(panel) && !path.includes(toolbar) && !path.includes(imageToolbar)) togglePanel(false);
  }
  shadow.addEventListener("pointerdown", dismissOutside, { capture: true });
  document.addEventListener("pointerdown", (event) => {
    if (!event.composedPath().includes(host)) dismissOutside(event);
  }, { capture: true });
  document.addEventListener("click", (event) => {
    if (!event.isTrusted) return;
    if (event.composedPath().includes(host) || !window.getSelection()?.isCollapsed || excluded) return;
    for (const [id, range] of ranges) {
      if ([...range.getClientRects()].some((rect) => event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom)) {
        const annotation = article?.annotations.find((item) => item.id === id);
        if (annotation) {
          event.preventDefault();
          openEditor(annotation, range.getBoundingClientRect(), false);
        }
        return;
      }
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.isTrusted && event.key === "Escape" && !event.isComposing) {
      toolbar.hidden = true;
      imageToolbar.hidden = true;
      closeEditor();
    }
  });
  window.addEventListener("scroll", () => {
    toolbar.hidden = true;
    imageToolbar.hidden = true;
  }, { passive: true });
  window.addEventListener("beforeunload", (event) => {
    if (editorDraft || pageDraft !== void 0 && pageDraft !== (article?.pageNote ?? "")) {
      event.preventDefault();
      event.returnValue = "";
    }
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "NOTING_TOGGLE") togglePanel();
    if (message.type === "NOTING_REFRESH") void refresh().catch((error) => toast(error.message, true));
  });
  var observer = new MutationObserver((records) => {
    if (!records.some((record) => !(record.target instanceof Element ? record.target : record.target.parentElement)?.closest("[data-noting-root]"))) return;
    clearTimeout(renderTimer);
    renderTimer = setTimeout(() => {
      restoreHighlights();
    }, 350);
  });
  observer.observe(document.body, { childList: true, characterData: true, subtree: true });
  var lastInteraction = performance.now();
  var lastTick = performance.now();
  var activeMs = 0;
  var lastSent = 0;
  var sessionId = crypto.randomUUID();
  var sessionStarted = (/* @__PURE__ */ new Date()).toISOString();
  var sessionDay = localDay();
  var readable = (0, import_readability2.isProbablyReaderable)(document);
  var readingInFlight = false;
  var maxProgress = 0;
  for (const event of ["pointerdown", "pointermove", "keydown", "wheel", "touchstart"]) {
    document.addEventListener(event, () => {
      lastInteraction = performance.now();
    }, { passive: true });
  }
  async function sendReading() {
    if (!ready || excluded || !settings.recordHistory || !readable || activeMs < 15e3 || readingInFlight) return;
    readingInFlight = true;
    const sent = activeMs;
    const sentSessionId = sessionId;
    try {
      await rpc({ type: "READING", page: page(!lastSent), session: { id: sessionId, day: sessionDay, startedAt: sessionStarted, activeMs: sent, progress: maxProgress } });
      if (sessionId === sentSessionId) lastSent = sent;
    } catch (error) {
      if (!chrome.runtime?.id) clearInterval(ticker);
    } finally {
      readingInFlight = false;
    }
  }
  function resetSession() {
    activeMs = 0;
    lastSent = 0;
    maxProgress = 0;
    sessionId = crypto.randomUUID();
    sessionStarted = (/* @__PURE__ */ new Date()).toISOString();
    sessionDay = localDay();
    lastTick = performance.now();
    lastInteraction = performance.now();
  }
  var ticker = setInterval(async () => {
    if (normalizeUrl(location.href) !== normalizeUrl(currentUrl)) {
      currentUrl = location.href;
      awaitingSiyuanResult = false;
      article = null;
      pageDraft = void 0;
      pageDraftBase = void 0;
      pageEditing = false;
      cachedBody = void 0;
      cachedMarkdown = void 0;
      publishedDate = void 0;
      bodyAttempted = false;
      toolbar.hidden = true;
      imageToolbar.hidden = true;
      imageTarget = null;
      editor.hidden = true;
      editorDraft = false;
      ready = false;
      resetSession();
      readable = (0, import_readability2.isProbablyReaderable)(document);
      await refresh().catch(() => void 0);
      return;
    }
    if (sessionDay !== localDay()) {
      await sendReading();
      resetSession();
    }
    const now = performance.now();
    const delta = now - lastTick;
    lastTick = now;
    if (document.visibilityState === "visible" && document.hasFocus() && now - lastInteraction < 6e4 && delta < 5e3 && settings.recordHistory && !excluded) {
      activeMs += delta;
      const height = document.documentElement.scrollHeight - innerHeight;
      maxProgress = Math.max(maxProgress, height > 0 ? Math.min(100, scrollY / height * 100) : 100);
    }
    if (activeMs >= 15e3 && (lastSent === 0 || activeMs - lastSent >= 1e4)) await sendReading();
  }, 1e3);
  document.addEventListener("visibilitychange", () => {
    lastTick = performance.now();
    if (document.hidden) void sendReading();
  });
  window.addEventListener("pagehide", () => {
    void sendReading();
  });
  setInterval(() => {
    if ((panelOpen || awaitingSiyuanResult) && document.visibilityState === "visible") void refreshOutputStatus().catch(() => void 0);
  }, 4e3);
  void refresh().catch((error) => toast(error.message, true));
})();
//# sourceMappingURL=content.js.map
