/*!
Underline Notes / 划线笔记
Copyright 2026 rockbotcc

https://github.com/rockbotcc/underline-notes

Licensed under the Apache License, Version 2.0.
See LICENSE for the full license text.

Third-party components retain their respective copyrights and licenses.
*/

// node_modules/idb/build/index.js
var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
var idbProxyableTypes;
var cursorAdvanceMethods;
function getIdbProxyableTypes() {
  return idbProxyableTypes || (idbProxyableTypes = [
    IDBIndex,
    IDBObjectStore,
    IDBCursor,
    IDBDatabase,
    IDBTransaction
  ]);
}
function getCursorAdvanceMethods() {
  return cursorAdvanceMethods || (cursorAdvanceMethods = ["advance", "continue", "continuePrimaryKey"].map((method) => IDBCursor.prototype[method]));
}
var transactionDoneMap = /* @__PURE__ */ new WeakMap();
var transformCache = /* @__PURE__ */ new WeakMap();
var reverseTransformCache = /* @__PURE__ */ new WeakMap();
function promisifyRequest(request) {
  const promise = new Promise((resolve, reject) => {
    const unlisten = () => {
      request.removeEventListener("success", success);
      request.removeEventListener("error", error);
    };
    const success = () => {
      resolve(wrap(request.result));
      unlisten();
    };
    const error = () => {
      reject(request.error);
      unlisten();
    };
    request.addEventListener("success", success);
    request.addEventListener("error", error);
  });
  reverseTransformCache.set(promise, request);
  return promise;
}
function cacheDonePromiseForTransaction(tx) {
  if (transactionDoneMap.has(tx))
    return;
  const done = new Promise((resolve, reject) => {
    const unlisten = () => {
      tx.removeEventListener("complete", complete);
      tx.removeEventListener("error", error);
      tx.removeEventListener("abort", error);
    };
    const complete = () => {
      resolve();
      unlisten();
    };
    const error = () => {
      reject(tx.error || new DOMException("AbortError", "AbortError"));
      unlisten();
    };
    tx.addEventListener("complete", complete);
    tx.addEventListener("error", error);
    tx.addEventListener("abort", error);
  });
  transactionDoneMap.set(tx, done);
}
var idbProxyTraps = {
  get(target, prop, receiver) {
    if (target instanceof IDBTransaction) {
      if (prop === "done")
        return transactionDoneMap.get(target);
      if (prop === "store") {
        return receiver.objectStoreNames[1] ? void 0 : receiver.objectStore(receiver.objectStoreNames[0]);
      }
    }
    return wrap(target[prop]);
  },
  set(target, prop, value) {
    target[prop] = value;
    return true;
  },
  has(target, prop) {
    if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
      return true;
    }
    return prop in target;
  }
};
function replaceTraps(callback) {
  idbProxyTraps = callback(idbProxyTraps);
}
function wrapFunction(func) {
  if (getCursorAdvanceMethods().includes(func)) {
    return function(...args) {
      func.apply(unwrap(this), args);
      return wrap(this.request);
    };
  }
  return function(...args) {
    return wrap(func.apply(unwrap(this), args));
  };
}
function transformCachableValue(value) {
  if (typeof value === "function")
    return wrapFunction(value);
  if (value instanceof IDBTransaction)
    cacheDonePromiseForTransaction(value);
  if (instanceOfAny(value, getIdbProxyableTypes()))
    return new Proxy(value, idbProxyTraps);
  return value;
}
function wrap(value) {
  if (value instanceof IDBRequest)
    return promisifyRequest(value);
  if (transformCache.has(value))
    return transformCache.get(value);
  const newValue = transformCachableValue(value);
  if (!Object.is(newValue, value)) {
    transformCache.set(value, newValue);
    reverseTransformCache.set(newValue, value);
  }
  return newValue;
}
var unwrap = (value) => reverseTransformCache.get(value);
function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
  const request = indexedDB.open(name, version);
  const openPromise = wrap(request);
  if (upgrade) {
    request.addEventListener("upgradeneeded", (event) => {
      upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
    });
  }
  if (blocked) {
    request.addEventListener("blocked", (event) => blocked(
      // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
      event.oldVersion,
      event.newVersion,
      event
    ));
  }
  openPromise.then((db) => {
    if (terminated)
      db.addEventListener("close", () => terminated());
    if (blocking) {
      db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
    }
  }).catch(() => {
  });
  return openPromise;
}
var readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
var writeMethods = ["put", "add", "delete", "clear"];
var cachedMethods = {};
function getMethod(target, prop) {
  if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
    return;
  }
  if (cachedMethods[prop])
    return cachedMethods[prop];
  const targetFuncName = prop.replace(/FromIndex$/, "");
  const useIndex = prop !== targetFuncName;
  const isWrite = writeMethods.includes(targetFuncName);
  if (
    // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))
  ) {
    return;
  }
  const method = async function(storeName, ...args) {
    const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
    let target2 = tx.store;
    if (useIndex)
      target2 = target2.index(args.shift());
    return (await Promise.all([
      target2[targetFuncName](...args),
      isWrite && tx.done
    ]))[0];
  };
  return cachedMethods[prop] = method;
}
replaceTraps((oldTraps) => ({
  ...oldTraps,
  get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
  has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
}));
var advanceMethodProps = ["advance", "continue", "continuePrimaryKey"];
var methodMap = {};
var advanceResults = /* @__PURE__ */ new WeakMap();
var ittrProxiedCursorToOriginalProxy = /* @__PURE__ */ new WeakMap();
var cursorIteratorTraps = {
  get(target, prop) {
    if (!advanceMethodProps.includes(prop))
      return target[prop];
    let cachedFunc = methodMap[prop];
    if (!cachedFunc) {
      cachedFunc = methodMap[prop] = function(...args) {
        advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
      };
    }
    return cachedFunc;
  }
};
async function* iterate(...args) {
  let cursor = this;
  if (!(cursor instanceof IDBCursor)) {
    cursor = await cursor.openCursor(...args);
  }
  if (!cursor)
    return;
  cursor = cursor;
  const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
  ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
  reverseTransformCache.set(proxiedCursor, unwrap(cursor));
  while (cursor) {
    yield proxiedCursor;
    cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
    advanceResults.delete(proxiedCursor);
  }
}
function isIteratorProp(target, prop) {
  return prop === Symbol.asyncIterator && instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor]) || prop === "iterate" && instanceOfAny(target, [IDBIndex, IDBObjectStore]);
}
replaceTraps((oldTraps) => ({
  ...oldTraps,
  get(target, prop, receiver) {
    if (isIteratorProp(target, prop))
      return iterate;
    return oldTraps.get(target, prop, receiver);
  },
  has(target, prop) {
    return isIteratorProp(target, prop) || oldTraps.has(target, prop);
  }
}));

// shared/model.ts
var DEFAULT_SETTINGS = {
  outputTarget: "obsidian",
  flomoApiUrl: "",
  recordHistory: false,
  excludedDomains: [],
  vaultName: "",
  vaultFolder: "Reading"
};
function localDay(date = /* @__PURE__ */ new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function obsidianUrl(settings, id) {
  const params = new URLSearchParams({ vault: settings.vaultName });
  const file = id ? `Articles/${id}.md` : "\u5361\u7247\u76D2.md";
  params.set("file", [settings.vaultFolder.replace(/^\/+|\/+$/g, ""), file].filter(Boolean).join("/"));
  return `obsidian://open?${params}`;
}

// browser/src/db.ts
var database = openDB("noting", 3, {
  upgrade(db, oldVersion) {
    if (oldVersion < 3) {
      db.createObjectStore("siyuanJobs", { keyPath: "key" });
      db.createObjectStore("siyuanBindings", { keyPath: "key" });
    }
    if (oldVersion < 2) db.createObjectStore("flomo", { keyPath: "key" });
    if (oldVersion >= 1) return;
    db.createObjectStore("articles", { keyPath: "id" });
    const sessions = db.createObjectStore("sessions", { keyPath: "id" });
    sessions.createIndex("articleId", "articleId");
    sessions.createIndex("day", "day");
    db.createObjectStore("pending", { keyPath: "key" });
    db.createObjectStore("files", { keyPath: "path" });
    db.createObjectStore("meta");
  }
});
async function getDirectory() {
  return await (await database).get("meta", "directory");
}

// browser/src/rpc.ts
async function rpc(message) {
  const result = await chrome.runtime.sendMessage(message);
  if (!result?.ok) throw new Error(result?.error || "\u6269\u5C55\u8FDE\u63A5\u5DF2\u65AD\u5F00\uFF0C\u8BF7\u5237\u65B0\u7F51\u9875\u540E\u91CD\u8BD5\u3002");
  return result.data;
}

// browser/src/ai-tags.ts
var DEFAULT_TAG_AI = { enabled: false, baseUrl: "", apiKey: "", model: "" };

// browser/src/options.ts
function get(id) {
  return document.getElementById(id);
}
get("extension-version").textContent = "v" + chrome.runtime.getManifest().version;
var currentSettings = DEFAULT_SETTINGS;
var busy = false;
function notice(message, error = false) {
  const node = get("notice");
  node.textContent = message;
  node.className = error ? "error" : "";
  node.hidden = false;
}
function action(id, callback) {
  get(id).addEventListener("click", async () => {
    if (busy) return;
    busy = true;
    const button = get(id);
    button.disabled = true;
    try {
      await callback();
      await refresh();
    } catch (error) {
      if (!(error instanceof DOMException && error.name === "AbortError")) notice(error instanceof Error ? error.message : String(error), true);
    } finally {
      button.disabled = false;
      busy = false;
    }
  });
}
async function refresh(fillForm = false) {
  const status = await rpc({ type: "STATUS" });
  currentSettings = status.settings;
  if (fillForm) {
    get("record-history").checked = currentSettings.recordHistory;
    get("excluded-domains").value = currentSettings.excludedDomains.join("\n");
    get("vault-name").value = currentSettings.vaultName;
    get("output-target").value = currentSettings.outputTarget;
    get("flomo-api-url").value = currentSettings.flomoApiUrl;
    get("siyuan-base-url").value = currentSettings.siyuan?.baseUrl || "http://127.0.0.1:6806";
    get("siyuan-token").value = currentSettings.siyuan?.apiToken || "";
    const notebook = get("siyuan-notebook");
    if (currentSettings.siyuan) {
      if (![...notebook.options].some((item) => item.value === currentSettings.siyuan.notebookId)) notebook.add(new Option(currentSettings.siyuan.notebookName || "\u5DF2\u8FDE\u63A5\u7B14\u8BB0\u672C", currentSettings.siyuan.notebookId));
      notebook.value = currentSettings.siyuan.notebookId;
    }
    const ai = currentSettings.ai ?? DEFAULT_TAG_AI;
    get("ai-enabled").checked = ai.enabled;
    get("ai-base-url").value = ai.baseUrl;
    get("ai-api-key").value = ai.apiKey;
    get("ai-model").value = ai.model;
    updateDestinationForm();
  }
  get("article-count").textContent = String(status.articles);
  get("ai-tag-error").hidden = !status.aiTagError;
  get("ai-tag-error").textContent = status.aiTagError || "";
  get("highlight-count").textContent = String(status.annotations);
  get("pending-count").textContent = String(status.pending.length);
  get("connection-state").textContent = status.directoryName ? "\u6587\u4EF6\u5939\u5DF2\u8FDE\u63A5" : "\u5C1A\u672A\u8FDE\u63A5";
  get("folder-name").textContent = status.directoryName ? `\u5DF2\u8FDE\u63A5 ${currentSettings.vaultName || "\u672C\u5730\u6587\u4EF6\u5939"}/${status.directoryName}/ \xB7 \u6458\u5F55\u548C\u6279\u6CE8\u4FDD\u5B58\u5728 Cards/ \u4E0B\u7684 Markdown \u6587\u4EF6\u4E2D\u3002` : "\u53EF\u4EE5\u65B0\u5EFA\u300C\u5212\u7EBF\u7B14\u8BB0\u300D\u6587\u4EF6\u5939\uFF0C\u4EE5\u540E\u4E5F\u80FD\u7528 Obsidian \u6253\u5F00\u5B83\u3002";
  get("sync-status").textContent = status.lastSync ? `\u6700\u8FD1\u540C\u6B65 ${new Date(status.lastSync).toLocaleString()}` : "\u5212\u7EBF\u548C\u7B14\u8BB0\u5148\u4FDD\u5B58\u5728\u6D4F\u89C8\u5668\u672C\u5730";
  const link = get("open-obsidian");
  link.hidden = !currentSettings.vaultName || !status.directoryName;
  link.href = obsidianUrl(currentSettings);
  const isFlomo = currentSettings.outputTarget === "flomo";
  const isSiyuan = currentSettings.outputTarget === "siyuan";
  const remote = isFlomo || isSiyuan;
  get("authorize").hidden = !status.directoryName;
  for (const id of ["local-flow", "local-help", "restore-directory"]) get(id).hidden = remote;
  get("choose-directory").textContent = remote ? "\u8FDE\u63A5 Obsidian \u6587\u4EF6\u5939\u4EE5\u8BFB\u53D6\u6807\u7B7E" : "\u9009\u62E9\u7B14\u8BB0\u6587\u4EF6\u5939";
  link.hidden ||= remote;
  get("connection-title").textContent = isFlomo ? "\u5199\u5165 flomo" : "\u8FDE\u63A5\u7B14\u8BB0\u6587\u4EF6\u5939";
  get("connection-description").textContent = isFlomo ? "\u6309\u6761\u5199\u5165\u5212\u7EBF\u548C\u7B14\u8BB0\uFF0C\u5931\u8D25\u540E\u4FDD\u7559\u5728\u672C\u673A\u961F\u5217\u4E2D\u91CD\u8BD5\u3002" : "\u65B0\u5EFA\u6216\u9009\u62E9\u6587\u4EF6\u5939\uFF0C\u8D44\u6599\u4F1A\u4FDD\u5B58\u5728\u5176\u4E2D\u7684 Reading/\u3002";
  if (isFlomo) {
    get("connection-state").textContent = currentSettings.flomoApiUrl ? "API \u5DF2\u914D\u7F6E" : "\u5C1A\u672A\u914D\u7F6E";
    get("folder-name").textContent = "\u6BCF\u6761\u8BB0\u5F55\u5305\u542B\u6458\u5F55\u6216\u6587\u7AE0\u7B14\u8BB0\u3001\u6279\u6CE8\u548C\u6765\u6E90\u94FE\u63A5\u3002\u5207\u6362\u5199\u5165\u4F4D\u7F6E\u4F1A\u6682\u505C\u539F\u4F4D\u7F6E\u7684\u5199\u5165\u3002";
  }
  if (isSiyuan) {
    get("connection-title").textContent = "\u5199\u5165\u601D\u6E90\u7B14\u8BB0";
    get("connection-description").textContent = "\u5148\u4FDD\u5B58\u672C\u5730\uFF0C\u518D\u5199\u5165\u601D\u6E90\uFF1B\u601D\u6E90\u5173\u95ED\u65F6\u4FDD\u7559\u961F\u5217\u3002";
    get("connection-state").textContent = currentSettings.siyuan ? "API \u5DF2\u914D\u7F6E" : "\u5C1A\u672A\u914D\u7F6E";
    get("folder-name").textContent = "\u65B0\u589E\u5361\u7247\u521B\u5EFA\u6587\u6863\uFF0C\u4FEE\u6539\u8FFD\u52A0\u7248\u672C\uFF0C\u601D\u6E90\u4E2D\u7684\u8865\u5199\u4F1A\u4FDD\u7559\u3002";
  }
  get("siyuan-recreate").hidden = !status.pending.some((item) => item.errorCode === "missing");
  get("sync-error").hidden = !status.syncError;
  get("sync-error").textContent = status.syncError || "";
}
async function flush() {
  await rpc({ type: "FLUSH" });
  const status = await rpc({ type: "STATUS" });
  if (status.syncError) throw new Error(status.syncError);
  if (status.settings.outputTarget === "siyuan") {
    notice(status.pending.length ? "\u601D\u6E90\u4ECD\u6709\u5F85\u5199\u5165\u5185\u5BB9\uFF0C\u8BF7\u67E5\u770B\u72B6\u6001\u6216\u7A0D\u540E\u91CD\u8BD5\u3002" : "\u601D\u6E90\u6CA1\u6709\u5F85\u5199\u5165\u7684\u7B14\u8BB0\u3002");
    return;
  }
  if (status.settings.outputTarget === "flomo") {
    notice(status.pending.length ? "\u6B63\u5728\u5199\u5165 flomo\uFF0C\u5269\u4F59\u8BB0\u5F55\u4F1A\u7EE7\u7EED\u91CD\u8BD5\u3002" : "flomo \u6CA1\u6709\u5F85\u5199\u5165\u7684\u7B14\u8BB0\u3002");
    return;
  }
  if (!status.directoryName) {
    notice("\u8BF7\u5148\u9009\u62E9\u7B14\u8BB0\u6587\u4EF6\u5939\u3002");
    return;
  }
  notice(status.pending.length ? "\u6B63\u5728\u540C\u6B65\uFF0C\u5269\u4F59\u8BB0\u5F55\u4F1A\u7EE7\u7EED\u91CD\u8BD5\u3002" : "\u7B14\u8BB0\u5DF2\u4E0E\u672C\u5730\u6587\u4EF6\u5939\u540C\u6B65\u3002");
}
action("choose-directory", async () => {
  const root = await window.showDirectoryPicker({ id: "noting-vault", mode: "readwrite" });
  if (await root.requestPermission({ mode: "readwrite" }) !== "granted") throw new Error("\u9700\u8981\u6587\u4EF6\u5939\u8BFB\u5199\u6743\u9650");
  const directory = await root.getDirectoryHandle("Reading", { create: true });
  await navigator.locks.request("noting-file-output", async () => {
    const db = await database;
    const existing = await getDirectory();
    const sameDirectory = existing && await existing.isSameEntry(directory);
    const tx = db.transaction(["meta", "files"], "readwrite");
    await tx.objectStore("meta").put(directory, "directory");
    await tx.objectStore("meta").delete("lastSync");
    await tx.objectStore("meta").delete("syncError");
    if (!sameDirectory) await tx.objectStore("files").clear();
    await tx.done;
  });
  const settings = { ...currentSettings, vaultName: root.name, vaultFolder: "Reading" };
  await rpc({ type: "SAVE_SETTINGS", settings });
  get("vault-name").value = root.name;
  await rpc({ type: "REQUEUE" });
  await flush();
});
action("authorize", async () => {
  const directory = await getDirectory();
  if (!directory) throw new Error("\u8BF7\u5148\u9009\u62E9\u6587\u4EF6\u5939");
  if (await directory.requestPermission({ mode: "readwrite" }) !== "granted") throw new Error("\u5C1A\u672A\u53D6\u5F97\u6587\u4EF6\u5939\u8BFB\u5199\u6743\u9650");
  await flush();
});
action("flush", flush);
function updateDestinationForm() {
  const isFlomo = get("output-target").value === "flomo";
  const isSiyuan = get("output-target").value === "siyuan";
  get("siyuan-settings").hidden = !isSiyuan;
  for (const id of ["siyuan-base-url", "siyuan-token", "siyuan-notebook"]) {
    get(id).required = isSiyuan;
    get(id).disabled = !isSiyuan;
  }
  get("flomo-settings").hidden = !isFlomo;
  get("vault-settings").hidden = isFlomo || isSiyuan;
  get("flomo-api-url").required = isFlomo;
}
get("output-target").addEventListener("change", updateDestinationForm);
for (const id of ["siyuan-base-url", "siyuan-token"]) get(id).addEventListener("input", () => {
  get("siyuan-notebook").replaceChildren(new Option("\u8BF7\u91CD\u65B0\u6D4B\u8BD5\u8FDE\u63A5", ""));
  get("siyuan-test-result").textContent = "";
});
action("siyuan-test", async () => {
  const result = await rpc({
    type: "SIYUAN_TEST",
    baseUrl: get("siyuan-base-url").value,
    apiToken: get("siyuan-token").value
  });
  const select = get("siyuan-notebook");
  select.replaceChildren(new Option("\u8BF7\u9009\u62E9\u7B14\u8BB0\u672C", ""), ...result.notebooks.map((item) => new Option(item.name, item.id)));
  if (result.notebooks.length === 1) select.value = result.notebooks[0].id;
  get("siyuan-test-result").textContent = `\u5DF2\u8FDE\u63A5\u601D\u6E90 ${result.version}\uFF0C\u627E\u5230 ${result.notebooks.length} \u4E2A\u5DF2\u6253\u5F00\u7B14\u8BB0\u672C\u3002`;
});
action("siyuan-backfill-images", async () => {
  notice("\u6B63\u5728\u6279\u91CF\u8865\u4F20\u56FE\u7247\uFF0C\u8BF7\u4FDD\u6301\u601D\u6E90\u8FD0\u884C\u2026");
  const result = await rpc({ type: "SIYUAN_BACKFILL_IMAGES" });
  notice(result.count ? `\u5DF2\u5B89\u6392 ${result.count} \u6761\u56FE\u7247\u7B14\u8BB0\u8865\u4F20\uFF0C\u5DF2\u5B8C\u6210\u7684\u4F1A\u81EA\u52A8\u8DF3\u8FC7\u3002\u5269\u4F59\u4EFB\u52A1\u5C06\u81EA\u52A8\u7EE7\u7EED\uFF0C\u8BF7\u67E5\u770B\u540C\u6B65\u72B6\u6001\u3002` : "\u5F53\u524D\u76EE\u6807\u6CA1\u6709\u53EF\u8865\u4F20\u7684\u5DF2\u540C\u6B65\u56FE\u7247\u7B14\u8BB0\u3002");
});
action("siyuan-recreate", async () => {
  if (!window.confirm("\u4E3A\u7F3A\u5931\u7684\u601D\u6E90\u76EE\u6807\u91CD\u65B0\u521B\u5EFA\u6587\u6863\uFF1F\u5DF2\u79FB\u51FA\u539F\u7B14\u8BB0\u672C\u7684\u6587\u6863\u4F1A\u4FDD\u7559\uFF0C\u65B0\u526F\u672C\u5C06\u5199\u5165\u5F53\u524D\u76EE\u6807\u3002")) return;
  await rpc({ type: "SIYUAN_RECREATE" });
  notice("\u5DF2\u5904\u7406\u7F3A\u5931\u6587\u6863\uFF0C\u8BF7\u67E5\u770B\u540C\u6B65\u72B6\u6001\u3002");
});
get("settings-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await rpc({ type: "SAVE_SETTINGS", settings: {
      ...currentSettings,
      ai: {
        enabled: get("ai-enabled").checked,
        baseUrl: get("ai-base-url").value.trim(),
        apiKey: get("ai-api-key").value.trim(),
        model: get("ai-model").value.trim()
      },
      outputTarget: get("output-target").value,
      flomoApiUrl: get("flomo-api-url").value.trim(),
      siyuan: get("output-target").value === "siyuan" ? {
        baseUrl: get("siyuan-base-url").value.trim(),
        apiToken: get("siyuan-token").value.trim(),
        notebookId: get("siyuan-notebook").value,
        profileId: ""
      } : currentSettings.siyuan,
      recordHistory: get("record-history").checked,
      excludedDomains: get("excluded-domains").value.split(/[\s,，]+/).filter(Boolean),
      vaultName: get("vault-name").value
    } });
    await refresh(true);
    notice("\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\u3002");
  } catch (error) {
    notice(error instanceof Error ? error.message : String(error), true);
  }
});
action("export-backup", async () => {
  const backup = await rpc({ type: "BACKUP" });
  const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = `underline-notes-backup-${localDay()}.json`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e4);
  notice("\u5DF2\u751F\u6210\u6D4F\u89C8\u5668\u8D44\u6599\u5907\u4EFD\u3002Obsidian \u4E2D\u8865\u5199\u7684\u5185\u5BB9\u8BF7\u968F\u4ED3\u5E93\u4E00\u8D77\u5907\u4EFD\u3002");
});
action("import-backup", async () => {
  get("backup-file").click();
});
get("backup-file").addEventListener("change", async (event) => {
  const input = event.target;
  const file = input.files?.[0];
  if (!file) return;
  try {
    if (file.size > 100 * 1024 * 1024) throw new Error("\u5907\u4EFD\u6587\u4EF6\u8D85\u8FC7 100 MB\uFF0C\u8BF7\u901A\u8FC7\u6587\u4EF6\u5939\u6062\u590D\u3002");
    const result = await rpc({ type: "IMPORT", backup: JSON.parse(await file.text()) });
    notice(`\u5DF2\u5408\u5E76 ${result.articles} \u7BC7\u6587\u7AE0\u548C ${result.sessions} \u6761\u9605\u8BFB\u8BB0\u5F55\u3002`);
    await refresh();
  } catch (error) {
    notice(error instanceof Error ? error.message : String(error), true);
  } finally {
    input.value = "";
  }
});
action("restore-directory", async () => {
  const directory = await getDirectory();
  if (!directory) throw new Error("\u8BF7\u5148\u8FDE\u63A5\u5305\u542B Reading \u6587\u4EF6\u5939\u7684\u4ED3\u5E93");
  if (await directory.requestPermission({ mode: "readwrite" }) !== "granted") throw new Error("\u9700\u8981\u6587\u4EF6\u5939\u8BBF\u95EE\u6743\u9650");
  const backup = { schemaVersion: 1, exportedAt: (/* @__PURE__ */ new Date()).toISOString(), articles: [], sessions: [] };
  await navigator.locks.request("noting-file-output", async () => {
    const data = await directory.getDirectoryHandle("Data");
    const articles = await data.getDirectoryHandle("articles");
    for await (const handle of articles.values()) {
      if (handle.kind !== "file" || !handle.name.endsWith(".json")) continue;
      const value = JSON.parse(await (await handle.getFile()).text());
      if (value.schemaVersion !== 1) throw new Error("\u6587\u4EF6\u5939\u683C\u5F0F\u7248\u672C\u4E0D\u53D7\u652F\u6301");
      backup.articles.push(value.article);
    }
    try {
      const history = await data.getDirectoryHandle("history");
      for await (const handle of history.values()) {
        if (handle.kind !== "file" || !handle.name.endsWith(".jsonl")) continue;
        for (const line of (await (await handle.getFile()).text()).split("\n").filter(Boolean)) {
          const value = JSON.parse(line);
          if (value.schemaVersion !== 1) throw new Error("\u9605\u8BFB\u8BB0\u5F55\u683C\u5F0F\u7248\u672C\u4E0D\u53D7\u652F\u6301");
          backup.sessions.push(value);
        }
      }
    } catch (error) {
      if (!(error instanceof DOMException && error.name === "NotFoundError")) throw error;
    }
  });
  const result = await rpc({ type: "IMPORT", backup });
  notice(`\u5DF2\u4ECE\u5F00\u653E\u683C\u5F0F\u6587\u4EF6\u6062\u590D ${result.articles} \u7BC7\u6587\u7AE0\u3002\u4FEE\u6539\u8FC7\u7684 Markdown \u4F1A\u4FDD\u7559\u5E76\u63D0\u793A\u51B2\u7A81\u3002`);
});
void refresh(true).catch((error) => notice(error.message, true));
setInterval(() => {
  if (!busy) void refresh().catch(() => void 0);
}, 4e3);
//# sourceMappingURL=options.js.map
